let currentPayrollList = [];

// =============================================================
// 0. QUẢN LÝ TRẠNG THÁI DUYỆT 
// =============================================================

//  Gọi API để kiểm tra xem bảng lương tháng/năm đã được duyệt chưa
async function isDaDuyet(month, year) {
    try {
        const token = localStorage.getItem('token');
        const res = await fetch(
            `http://localhost:8080/api/bang-luong/trang-thai?month=${month}&year=${year}`,
            { headers: { 'Authorization': 'Bearer ' + token } }
        );
        if (!res.ok) return false;
        const data = await res.json();
        return data.daDuyet === true;
    } catch {
        return false;
    }
}

async function capNhatUIDuyet() {
    const month = document.getElementById('salaryMonth')?.value.padStart(2, '0');//02
    const year  = document.getElementById('salaryYear')?.value;
    if (!month || !year) return;

    const daDuyet  = await isDaDuyet(month, year);
    const badge    = document.getElementById('badgeDuyetLuong'); // nút trạng thái duyệt ở góc trên bên phải tiêu đề
    const btnTinh  = document.getElementById('btnTinhLuong'); // nút TÍNH LƯƠNG
    const btnDuyet = document.getElementById('btnDuyetLuong'); // nút DUYỆT BẢNG LƯƠNG

    if (daDuyet) {
        if (badge) {
            badge.innerHTML = '<i class="fa-solid fa-circle-check"></i> Đã duyệt';
            badge.style.background   = '#dcfce7';
            badge.style.color        = '#166534';
            badge.style.borderColor  = '#86efac';
        }
        if (btnTinh) {
            btnTinh.disabled = true;
            btnTinh.title = `Bảng lương tháng ${month}/${year} đã được duyệt, không thể tính lại!`;
        }
        if (btnDuyet) {
            btnDuyet.disabled = true;
            btnDuyet.classList.add('da-duyet');
            btnDuyet.innerHTML = '<i class="fa-solid fa-circle-check"></i> Đã duyệt';
        }
    } else {
        if (badge) {
            badge.innerHTML = '<i class="fa-solid fa-clock"></i> Chưa duyệt';
            badge.style.background   = '#fef9c3';
            badge.style.color        = '#92400e';
            badge.style.borderColor  = '#fde68a';
        }
        if (btnTinh) {
            btnTinh.disabled = false;
            btnTinh.title = '';
        }
        if (btnDuyet) {
            btnDuyet.disabled = false;
            btnDuyet.classList.remove('da-duyet');
            btnDuyet.innerHTML = '<i class="fa-solid fa-circle-check"></i> Duyệt bảng lương';
        }
    }
}

async function duyetBangLuong() {
    const month = document.getElementById('salaryMonth')?.value.padStart(2, '0');
    const year  = document.getElementById('salaryYear')?.value;
    if (!month || !year) return;

    if (!currentPayrollList || currentPayrollList.length === 0) {
        alert(`Chưa có dữ liệu lương tháng ${month}/${year}.\nVui lòng bấm TÍNH LƯƠNG trước khi duyệt!`);
        return;
    }

    // Kiểm tra từ DB trước
    const daDuyet = await isDaDuyet(month, year);
    if (daDuyet) {
        alert(`Bảng lương tháng ${month}/${year} đã được duyệt trước đó!`);
        await capNhatUIDuyet();
        return;
    }

    // Lấy tên người duyệt từ localStorage
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const ten = currentUser?.fullname || 'Quản trị viên';

    if (!confirm(
        `Xác nhận DUYỆT bảng lương tháng ${month}/${year}?\n\n` +
        `• Bảng lương sẽ bị KHÓA, không thể tính lại\n` +
        `• Người duyệt: ${ten}`
    )) return;

    try {
        const token = localStorage.getItem('token');
        const res = await fetch(
            `http://localhost:8080/api/bang-luong/duyet?month=${month}&year=${year}&nguoiDuyet=${encodeURIComponent(ten)}`,
            {
                method: 'POST',
                headers: { 'Authorization': 'Bearer ' + token }
            }
        );
        if (!res.ok) {
            const err = await res.text();
            throw new Error(err);
        }
        alert(`Đã duyệt bảng lương tháng ${month}/${year} thành công!\nNgười duyệt: ${ten}`);
        await capNhatUIDuyet(); 
    } catch (error) {
        alert(` Lỗi khi duyệt: ${error.message}`);
    }
}

// =============================================================
// 1. TÍNH LƯƠNG
// =============================================================
async function calculatePayroll() {
    const monthInput = document.getElementById('salaryMonth');
    const yearInput  = document.getElementById('salaryYear');
    if (!monthInput || !yearInput) return;

    const month = monthInput.value.padStart(2, '0');
    const year  = yearInput.value;

    // Kiểm tra từ DB
    const daDuyet = await isDaDuyet(month, year);
    if (daDuyet) {
        alert(`🔒 Bảng lương tháng ${month}/${year} đã được DUYỆT!\nKhông thể tính lại.`);
        return;
    }

    if (!confirm(`Hệ thống sẽ tính toán (hoặc ghi đè) bảng lương tháng ${month}/${year}. Bạn có chắc chắn?`)) {
        return;
    }

    const token = localStorage.getItem('token');
    fetch(`http://localhost:8080/api/bang-luong/tinh-toan?month=${month}&year=${year}`, {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json'
        }
    })
    .then(async response => {
        if (!response.ok) {
            if (response.status === 401 || response.status === 403) {
                throw new Error("Không có quyền truy cập hoặc phiên đăng nhập đã hết hạn!");
            }
            const err = await response.text();
            throw new Error(err);
        }
        return response.json();
    })
    // cập nhật lại bảng lương sau khi tính toán xong
    .then(data => {
        currentPayrollList = data;
        renderPayrollTable(data);
        alert(`✅ Đã tính lương xong cho tháng ${month}/${year}!`);
    })
    .catch(error => {
        console.error("Lỗi:", error);
        alert(`❌ LỖI API: ${error.message}`);
    });
}

// =============================================================
// 2. LẤY DỮ LIỆU BẢNG LƯƠNG TỪ API
// =============================================================
function loadPayrollHistory() {
    const monthInput = document.getElementById('salaryMonth');
    const yearInput  = document.getElementById('salaryYear');
    if (!monthInput || !yearInput) return;

    const month = monthInput.value.padStart(2, '0');
    const year  = yearInput.value;

    const token = localStorage.getItem('token');
    fetch(`http://localhost:8080/api/bang-luong/chi-tiet?month=${month}&year=${year}`, {
        headers: { 'Authorization': 'Bearer ' + token }
    })
    .then(async response => {
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        return response.json();
    })
    .then(data => {
        currentPayrollList = data;
        renderPayrollTable(data); // hàm vẽ bảng lương ở phần 3 bên dưới
    })
    .catch(error => {
        console.error("Lỗi lấy danh sách lương:", error);
        currentPayrollList = [];
        renderPayrollTable([]);
    });
}

// =============================================================
// 3. HIỂN THỊ BẢNG LƯƠNG
// =============================================================
function renderPayrollTable(data) {
    // Xóa bảng cũ
    const tbody = document.getElementById('salaryTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';

    if (!data || data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 30px;">Vui lòng chọn tháng và bấm nút "TÍNH LƯƠNG"</td></tr>';
        return;
    }

    data.forEach(p => {
        const tr = document.createElement('tr');
        if (p.note) tr.style.backgroundColor = '#fffbeb';

        let empName = "Chưa rõ tên";
        if (typeof listEmployees !== 'undefined') {
            const emp = listEmployees.find(e => String(e.id) === String(p.maNV)); 
            if (emp) empName = emp.name;
        }

        const staffId = p.maNV ? `NV${String(p.maNV).padStart(3, '0')}` : "---";

        tr.innerHTML = `
            <td style="padding-left: 20px;">
                <div style="display: flex; flex-direction: column; justify-content: center;">
                    <div style="font-weight: 600; color: #1f2937;">${empName}</div>
                    <div style="font-size: 11px; color: #6b7280; margin-top: 4px;">
                        ${staffId}
                        ${p.note ? `<span style="color:#d97706; font-weight:bold; margin-left: 8px;"><i class="fa-solid fa-triangle-exclamation"></i> ${p.note}</span>` : ''}
                    </div>
                </div>
            </td>
            <td style="font-weight: 500;">${(p.baseSalary || 0).toLocaleString()}</td>
            <td style="text-align: center;">
                <div>${p.workDays || 0} công</div>
                <div style="font-size: 10px; color: #9ca3af">Nghỉ: ${p.leaveDays || 0}</div>
            </td>
            <td>
                <div style="color: #16a34a; font-weight: 500;">+${Math.round(p.overtimeMoney || 0).toLocaleString()}</div>
                <div style="font-size: 10px; color: #6b7280">(${p.otHours || 0} giờ)</div>
            </td>
            <td style="color: #16a34a;">+${(p.allowance || 0).toLocaleString()}</td>
            <td style="color: #dc2626;">-${(p.deduction || 0).toLocaleString()}</td>
            <td>
                <span style="background: #eff6ff; color: #2563eb; padding: 6px 12px; border-radius: 6px; font-weight: 700;">
                    ${Math.round(p.total || 0).toLocaleString()} đ
                </span>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// =============================================================
// 4. ĐIỀU HƯỚNG
// =============================================================
async function showSalarySection() {
    document.querySelectorAll('.content-body').forEach(el => el.style.display = 'none'); 
    document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active')); 

    const section = document.getElementById('salary-section');
    if (section) {
        section.style.display = 'block';
        const menuBtn = document.getElementById('menu-luong');
        if (menuBtn) menuBtn.classList.add('active');

        await loadAllDataFromAPI();
        loadPayrollHistory();
        loadDeptFilterLuong();
        await capNhatUIDuyet();
    }
}

// =============================================================
// 5. TÌM KIẾM
// =============================================================
function handleSearchLuong() {
    const keywordInput = document.getElementById('searchLuong');
    const deptInput    = document.getElementById('filterDeptLuong');
    if (!keywordInput || !deptInput) return;

    const keyword    = keywordInput.value.toLowerCase().trim();
    const deptFilter = deptInput.value;

    // Lọc lấy những dòng mà (Tên hoặc Mã có chứa từ khóa) VÀ Phòng ban khớp với lựa chọn
    const filtered = currentPayrollList.filter(item => {
        let empName = "", empDept = "";
        if (typeof listEmployees !== 'undefined') {
            const emp = listEmployees.find(e => String(e.id) === String(item.maNV));
            // Nếu tìm thấy nhân viên, lấy tên và phòng ban để so sánh
            if (emp) { empName = emp.name.toLowerCase(); empDept = emp.dept; }
        }
        const idStr = String(item.maNV || "").toLowerCase();
        return (empName.includes(keyword) || idStr.includes(keyword)) &&
               (deptFilter === "" || empDept === deptFilter);
    });
// Cập nhật lại bảng với dữ liệu đã lọc
    renderPayrollTable(filtered);
}

// =============================================================
// 6. XUẤT EXCEL
// =============================================================
function exportPayrollExcel() {
    const month = document.getElementById('salaryMonth').value;
    const year  = document.getElementById('salaryYear').value;

    if (!currentPayrollList || currentPayrollList.length === 0) {
        alert(`❌ Chưa có dữ liệu lương tháng ${month}/${year}!\nVui lòng bấm 'TÍNH LƯƠNG' trước.`);
        return;
    }

    const dataToExport = currentPayrollList.map(item => {
        let empName = "---", empRole = "---";
        if (typeof listEmployees !== 'undefined') {
            const emp = listEmployees.find(e => e.id === (item.maNV));
            if (emp) { empName = emp.name; empRole = emp.role; }
        }
        return {
            "Mã NV":           item.maNV,
            "Họ và Tên":       empName,
            "Chức vụ":         empRole,
            "Lương Cơ Bản":    item.baseSalary,
            "Ngày Công":       item.workDays,
            "Nghỉ Phép":       item.leaveDays,
            "Giờ Tăng Ca":     item.otHours,
            "Tiền Tăng Ca":    item.overtimeMoney,
            "Phụ Cấp":         item.allowance,
            "Khấu Trừ":        item.deduction,
            "THỰC LÃNH (VND)": item.total,
            "Ghi chú":         item.note || ""
        };
    });

    if (typeof XLSX === 'undefined') {
        alert("Lỗi: Chưa nhúng thư viện XLSX. Vui lòng thêm thẻ script vào HTML.");
        return;
    }

    const ws = XLSX.utils.json_to_sheet(dataToExport);// Chuyển dữ liệu JSON thành sheet
    ws['!cols'] = [
        {wch:10},{wch:25},{wch:15},{wch:15},{wch:10},
        {wch:10},{wch:10},{wch:15},{wch:15},{wch:15},{wch:20},{wch:20}
    ];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, `Luong_T${month}_${year}`);
    XLSX.writeFile(wb, `Bang_Luong_Thang_${month}_${year}.xlsx`);
}

// =============================================================
// 7. SỰ KIỆN KHI MỞ TRANG
// =============================================================
document.addEventListener("DOMContentLoaded", function() {
    const salaryMonth = document.getElementById('salaryMonth');
    const salaryYear  = document.getElementById('salaryYear');
    const searchInput = document.getElementById('searchLuong');
    const deptInput   = document.getElementById('filterDeptLuong');

    if (salaryMonth && salaryYear) {
        // Khi thay đổi tháng hoặc năm, tự động tải lại bảng lương và cập nhật trạng thái duyệt
        salaryMonth.addEventListener('change', async () => {
            loadPayrollHistory();
            await capNhatUIDuyet();
        });
        salaryYear.addEventListener('change', async () => {
            loadPayrollHistory();
            await capNhatUIDuyet();
        });
    }
    // Sự kiện tìm kiếm và lọc
    if (searchInput) searchInput.addEventListener('input', handleSearchLuong);
    if (deptInput)   deptInput.addEventListener('change', handleSearchLuong);
});

function loadDeptFilterLuong() {
    const select = document.getElementById('filterDeptLuong');
    if (!select || typeof danhSachPhongBan === 'undefined' || !danhSachPhongBan) return;
    select.innerHTML = '<option value="">Tất cả phòng ban</option>';
    danhSachPhongBan.forEach(pb => {
        select.innerHTML += `<option value="${pb.tenPB}">${pb.tenPB}</option>`; 
    });
}




















// =============================================================
// API BACKEND ĐƯỢC GỌI TRONG FILE NÀY
// =============================================================
// 1. isDaDuyet() - Kiểm tra bảng lương đã duyệt chưa
//    - GET /api/bang-luong/trang-thai?month={month}&year={year}  → BangLuongController
//
// 2. duyetBangLuong() - Duyệt bảng lương
//    - POST /api/bang-luong/duyet?month={month}&year={year}&nguoiDuyet={ten} → BangLuongController
//
// 3. calculatePayroll() - Tính lương
//    - POST /api/bang-luong/tinh-toan?month={month}&year={year}  → BangLuongController
//
// 4. loadPayrollHistory() - Lấy danh sách bảng lương
//    - GET /api/bang-luong/chi-tiet?month={month}&year={year}    → BangLuongController
//
// 5. showSalarySection() - Dùng chung từ nhanvien.js
//    - GET /api/phong-ban/danh-sach                              → PhongBanController
//    - GET /api/chuc-vu/danh-sach                                → ChucVuController
//    - GET /api/nhan-vien/danh-sach                              → NhanVienController
//
// 6. exportPayrollExcel() - Xuất Excel (không gọi API, dùng thư viện XLSX)
// =============================================================