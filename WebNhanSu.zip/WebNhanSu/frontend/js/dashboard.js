/* global Chart */
/* eslint-disable no-unused-vars */

// =============================================================
// PHẦN 1: XÁC THỰC & PHÂN QUYỀN NGƯỜI DÙNG, THIẾT LẬP GIAO DIỆN THEO ROLE
// =============================================================
document.addEventListener("DOMContentLoaded", function() {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));

    if (!currentUser) {
        alert("Bạn chưa đăng nhập! Hệ thống sẽ chuyển về trang đăng nhập.");
        window.location.href = "login.html"; 
        return;
    }

    const nameDisplay = document.getElementById('userNameDisplay');
    const roleDisplay = document.querySelector('.user-info .role'); 
    
    if (nameDisplay) nameDisplay.innerText = currentUser.fullname;
    if (roleDisplay) roleDisplay.innerText = getRoleName(currentUser.role);

    setupMenuByRole(currentUser.role);

    // Thiết lập link sự kiện nút đăng xuất (từ nhiều trang)
    const logoutLinks = document.querySelectorAll('a[href="login.html"], #btnLogout');
    logoutLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault(); 
            if(confirm("Bạn có chắc chắn muốn đăng xuất?")) {
                localStorage.removeItem('currentUser'); 
                window.location.href = "login.html"; 
            }
        });
    });

    if (currentUser.role === 'ADMIN' || currentUser.role === 'HR' || currentUser.role === 'ACCOUNTANT') {
        loadDashboardData();
    } else {
        const dashboardSection = document.getElementById('dashboard-section');
        if(dashboardSection) {
            dashboardSection.innerHTML = '<div style="padding:20px; text-align:center;">Chào mừng trở lại! Hãy chọn menu bên trái để sử dụng chức năng.</div>';
        }
    }
    loadAllDataFromAPI();
});

function getRoleName(role) {
    switch(role) {
        case 'ADMIN': return 'Quản trị hệ thống';
        case 'HR': return 'Chuyên viên Nhân sự';
        case 'ACCOUNTANT': return 'Kế toán viên';
        case 'EMPLOYEE': return 'Nhân viên';
        default: return 'Khách';
    }
}

function setupMenuByRole(role) {
    const menuNhanVien = document.getElementById('menu-nhanvien');
    const menuChamCong = document.getElementById('menu-chamcong'); 
    const menuHopDong  = document.getElementById('menu-hopdong');  
    const menuLuong    = document.getElementById('menu-luong');

    if(menuNhanVien) menuNhanVien.style.display = 'none';
    if(menuChamCong) menuChamCong.style.display = 'none';
    if(menuHopDong) menuHopDong.style.display = 'none';
    if(menuLuong) menuLuong.style.display = 'none';

    if (role === 'ADMIN') {
        if(menuNhanVien) menuNhanVien.style.display = 'block';
        if(menuChamCong) menuChamCong.style.display = 'block';
        if(menuHopDong) menuHopDong.style.display = 'block';
        if(menuLuong) menuLuong.style.display = 'block';
    } else if (role === 'HR') {
        if(menuNhanVien) menuNhanVien.style.display = 'block';
        if(menuHopDong) menuHopDong.style.display = 'block';
    } else if (role === 'ACCOUNTANT') {
        if(menuChamCong) menuChamCong.style.display = 'block';
        if(menuLuong) menuLuong.style.display = 'block';
    }
}

// =============================================================
// PHẦN 2: HÀM TẢI DỮ LIỆU CHO DASHBOARD VÀ HÀM VẼ BIỂU ĐỒ
// =============================================================

async function loadDashboardData() {
    console.log("...Đang tải số liệu Dashboard từ API...");

    try {
        const response = await apiFetch('http://localhost:8080/api/dashboard/summary', {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        if (!response.ok) throw new Error("Lỗi mạng khi gọi API");
        const result = await response.json();
        
        if (result.status === "success") {
            const data = result.data;

            // 1. ĐIỀN SỐ VÀO HTML (4 ô)
            safeSetText('totalEmp', data.overview.totalEmployees);
            safeSetText('activeEmp', data.overview.activeEmployees);
            safeSetText('activeContracts', data.overview.activeContracts);
            safeSetText('avgSalary', formatCompactNumber(data.overview.averageSalary));

            // 2. GỌI CÁC HÀM VẼ BIỂU ĐỒ (Dữ liệu đã được gom nhóm sẵn từ Java)
            renderRoleChart(data.charts.roleCounts);
            renderDeptChart(data.charts.deptCounts); 
            renderSalaryChart(data.charts.salaryByRole); 
            renderDeptSalaryChart(data.charts.salaryByDept);
            renderNewestEmployees(data.newestEmployees);
        }

    } catch (error) {
        console.error("Lỗi lấy dữ liệu:", error);
    }
}

function safeSetText(id, value) {
    const el = document.getElementById(id);
    if (el) el.innerText = value || '0';
}

function formatCompactNumber(number) {
    if (!number) return '0';
    if (number >= 1000000000) return (number / 1000000000).toFixed(1) + 'B'; 
    if (number >= 1000000) return (number / 1000000).toFixed(1) + 'M'; 
    return number.toLocaleString();
}

// --- BIỂU ĐỒ TRÒN (PHÂN BỔ CHỨC VỤ) ---
let myRoleChart = null; 
function renderRoleChart(roleCounts = {}) {
    const ctx = document.getElementById('roleChart');
    if (!ctx || typeof Chart === 'undefined') return;

    if (myRoleChart) myRoleChart.destroy(); 

    myRoleChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(roleCounts), 
            datasets: [{
                data: Object.values(roleCounts), 
                backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#6366f1'],
                borderWidth: 0
            }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right' } } }
    });
}

// --- BIỂU ĐỒ TRÒN (PHÂN BỔ THEO PHÒNG BAN) ---
let myDeptChart = null;
function renderDeptChart(deptCounts = {}) {
    const ctx = document.getElementById('deptChart');
    if (!ctx || typeof Chart === 'undefined') return;

    if (myDeptChart) myDeptChart.destroy();

    myDeptChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(deptCounts),
            datasets: [{
                data: Object.values(deptCounts),
                backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#6366f1'],
                borderWidth: 0 
            }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'right' }, datalabels: { display: false } } }
    });
}

// --- BIỂU ĐỒ CỘT (TỔNG LƯƠNG THEO CHỨC VỤ) ---
let mySalaryChart = null;
function renderSalaryChart(salaryByRole = {}) {
    const ctx = document.getElementById('salaryChart');
    if (!ctx || typeof Chart === 'undefined') return;

    if (mySalaryChart) mySalaryChart.destroy();

    mySalaryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(salaryByRole),
            datasets: [{
                label: 'Tổng quỹ lương (VNĐ)',
                data: Object.values(salaryByRole),
                backgroundColor: '#3b82f6',
                borderRadius: 4, 
                barPercentage: 0.6 
            }]
        },
        options: { 
            responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { callback: function(value) { return value >= 1000000 ? value / 1000000 + 'M' : value; } } } }
        }
    });
}

// --- BIỂU ĐỒ CỘT: TỔNG LƯƠNG PHÒNG BAN ---
let myDeptSalaryChart = null;
function renderDeptSalaryChart(salaryByDept = {}) {
    const ctx = document.getElementById('deptSalaryChart');
    if (!ctx || typeof Chart === 'undefined') return;

    if (myDeptSalaryChart) myDeptSalaryChart.destroy();

    myDeptSalaryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(salaryByDept),
            datasets: [{
                label: 'Quỹ lương (VNĐ)',
                data: Object.values(salaryByDept),
                backgroundColor: '#10b981',
                borderRadius: 4
            }]
        },
        options: { 
            responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: (ctx) => `Tổng: ${ctx.raw.toLocaleString()} VNĐ` } } },
            scales: { y: { beginAtZero: true, ticks: { callback: (val) => val >= 1000000 ? (val / 1000000) + 'M' : val } } }
        }
    });
}

// --- DANH SÁCH NHÂN VIÊN MỚI GIA NHẬP ---
function renderNewestEmployees(newest = []) {
    const container = document.getElementById('newEmpList');
    if (!container) return;
    
    container.innerHTML = '';

    newest.forEach(e => {
        const initial = e.name ? e.name.split(' ').pop().charAt(0) : '?';
        
        // Tra tên chức vụ từ mảng danhSachChucVu
        const cv = danhSachChucVu.find(c => c.idcv === e.idcv || c.idcv === e.role);
        const tenCV = cv ? cv.tenCV : (e.role || 'Chưa xếp');
        
        const html = `
            <div style="display: flex; align-items: center; gap: 12px; padding: 10px; border: 1px solid #f3f4f6; border-radius: 8px; margin-bottom: 10px;">
                <div style="width: 36px; height: 36px; background: #f3f4f6; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #4b5563;">
                    ${initial}
                </div>
                <div style="flex: 1;">
                    <div style="font-weight: 600; font-size: 13px; color: #1f2937;">${e.name || 'Chưa cập nhật'}</div>
                    <div style="font-size: 11px; color: #6b7280;">${tenCV}</div>
                </div>
                <span style="font-size: 10px; padding: 2px 6px; background: #ecfdf5; color: #059669; border-radius: 4px;">Mới</span>
            </div>
        `;
        container.innerHTML += html;
    });
}

// =============================================================
// PHẦN 3: HÀM CHUYỂN TRANG VÀ CÁC HÀM PHỤ TRỢ KHÁC
// =============================================================
function showDashboardSection() {
    // Ẩn tất cả các section khác, chỉ hiển thị section Dashboard
    const allSections = document.querySelectorAll('.content-body');
    allSections.forEach(section => {
        section.style.display = 'none';
    });

    const dashboardSection = document.getElementById('dashboard-section');
    if (dashboardSection) {
        dashboardSection.style.display = 'block';
    }

    const allMenuItems = document.querySelectorAll('.menu-item');
    allMenuItems.forEach(item => item.classList.remove('active'));

    const menuBtn = document.getElementById('menu-tongquan');
    if (menuBtn) {
        menuBtn.classList.add('active');
    }

    loadDashboardData();
}


























//// =============================================================
// API BACKEND ĐƯỢC GỌI TRONG FILE NÀY
// =============================================================
// 1. loadDashboardData() - Tải toàn bộ dữ liệu dashboard
//    - GET /api/dashboard/summary → DashboardController → DashboardService
//
//    Dữ liệu trả về gồm:
//    a) overview:
//       - totalEmployees    → NhanVienRepository.count()
//       - activeEmployees   → NhanVienRepository.countByDaThoiViec(0)
//       - activeContracts   → HopDongRepository.countActiveContracts()
//       - averageSalary     → HopDongRepository.getAverageSalary()
//
//    b) charts:
//       - roleCounts        → NhanVienRepository.countByChucVu()
//       - deptCounts        → NhanVienRepository.countByPhongBan()
//       - salaryByRole      → HopDongRepository.sumSalaryByChucVu()
//       - salaryByDept      → HopDongRepository.sumSalaryByPhongBan()
//
//    c) newestEmployees     → NhanVienRepository.findTop6ByOrderByMaNVDesc()
//
// LƯU Ý: File này chỉ gọi DUY NHẤT 1 API, backend tự tính toán hết
// =============================================================