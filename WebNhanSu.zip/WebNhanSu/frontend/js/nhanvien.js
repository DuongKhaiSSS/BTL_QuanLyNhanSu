/* eslint-disable no-unused-vars */

// =============================================================
// 1. KHỞI TẠO BIẾN TOÀN CỤC & HÀM CHUYỂN ĐỔI (MAPPING)
// =============================================================
let listEmployees = []; 
let danhSachPhongBan = [];
let danhSachChucVu = [];

let currentPage = 1;
const itemsPerPage = 10;

let selectedYear = new Date().getFullYear();
let salaryMapByEmp = {};// mảng lưu trữ tổng lương theo năm của từng nhân viên
let sortOrder = null; // null = chưa sắp xếp, 'asc' = tăng, 'desc' = giảm

function mapDataFromServer(serverData) {
    return serverData.map(emp => {
        const pb = danhSachPhongBan.find(p => p.idpb === emp.idpb);
        const cv = danhSachChucVu.find(c => c.idcv === emp.idcv);

        let finalAvatar = emp.hinhAnh;
        if (!finalAvatar || (finalAvatar.indexOf("http") === -1 && finalAvatar.indexOf("data:image") === -1)) {
            finalAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(emp.hoTen || "NV")}&background=random&color=fff`;
        }

        // MAPPING DỮ LIỆU VỀ ĐỊNH DẠNG DÙNG CHO FRONTEND
        return {
            id: emp.maNV, 
            name: emp.hoTen || "Chưa cập nhật",
            email: `nv${emp.maNV}@congty.vn`, 
            idpb: emp.idpb,
            idcv: emp.idcv,
            dept: pb ? pb.tenPB : "Chưa phân phòng",
            role: cv ? cv.tenCV : "Chưa có chức vụ",
            status: emp.daThoiViec === 1 ? "Leave" : "Active", 
            avatar: finalAvatar,
            phone: emp.dienThoai || "",
            birth: emp.ngaySinh || "",
            cccd: emp.cccd || "",
            address: emp.diaChi || "",
            gender: emp.gioiTinh === 1 ? "Nam" : "Nữ"
        };
    });
}

// =============================================================
// 2. GỌI API VÀ TẢI DỮ LIỆU LÊN TRANG
// =============================================================
function loadAllDataFromAPI() {
    return Promise.all([
        apiFetch('http://localhost:8080/api/phong-ban/danh-sach').then(res => res.json()),
        apiFetch('http://localhost:8080/api/chuc-vu/danh-sach').then(res => res.json()),
        apiFetch('http://localhost:8080/api/nhan-vien/danh-sach').then(res => res.json())
    ])
    .then(([phongBans, chucVus, nhanViens])  => {
        danhSachPhongBan = phongBans;
        danhSachChucVu = chucVus;
        loadOptionsToSelect();
        listEmployees = mapDataFromServer(nhanViens);
        console.log("Dữ liệu từ SQL đã lên:", listEmployees);
        // load tổng lương cho năm đã chọn trước khi render bảng, để có dữ liệu hiển thị ngay
        loadAllSalariesForYear(selectedYear).then(() => {
            renderEmployeeTable(listEmployees);
        });
    })
    .catch(error => console.error("Lỗi khi tải dữ liệu tổng:", error));
}

// =============================================================
// 3. SỰ KIỆN KHI TRANG LOAD
// =============================================================
document.addEventListener("DOMContentLoaded", function() {
    loadAllDataFromAPI();

    // Gắn sự kiện cho ô tìm kiếm và bộ lọc phòng ban
    const searchBox = document.getElementById('searchEmp');
    const deptFilter = document.getElementById('filterDept');
    if (searchBox) searchBox.addEventListener('input', handleSearchFilter);
    if (deptFilter) deptFilter.addEventListener('change', handleSearchFilter);

    // Gắn sự kiện cho bộ lọc năm và sắp xếp lương
    const menuNhanVien = document.getElementById('menu-nhanvien');
    const allSections = document.querySelectorAll('.content-body'); 
    const empSection = document.getElementById('employee-section') || document.getElementById('employeeTableSection');

    if (menuNhanVien) {
        menuNhanVien.addEventListener('click', function(e) {
            // Khi click vào menu NV, sẽ reset tất cả filter về mặc định, reset trang về 1, và load lại dữ liệu để đảm bảo luôn có dữ liệu mới nhất từ server
            e.preventDefault();
            document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
            this.classList.add('active');

            allSections.forEach(sec => sec.style.display = 'none');
            if(empSection) empSection.style.display = 'block';
            
            const detailSection = document.getElementById('employee-detail-section');
            if(detailSection) detailSection.style.display = 'none';

            loadAllDataFromAPI();
        });
    }
});

// =============================================================
// 4. VẼ BẢNG NHÂN VIÊN 
// =============================================================
function renderEmployeeTable(data = listEmployees) {
    const tbody = document.getElementById('employeeTableBody');
    const pageInfo = document.getElementById('pageInfo');
    const paginationControls = document.getElementById('paginationControls');
    
    if (!tbody) return;
    tbody.innerHTML = '';

    const totalItems = data.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    
    if (currentPage > totalPages) currentPage = 1;
    if (currentPage < 1) currentPage = 1;

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, totalItems);
    const dataDisplay = data.slice(startIndex, endIndex);

    if(totalItems === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 20px;">Hệ thống chưa có nhân viên nào!</td></tr>';
        if(pageInfo) pageInfo.innerText = 'Hiển thị 0 nhân viên';
        return;
    }

    dataDisplay.forEach(emp => {
        let statusBadge = emp.status === 'Active' 
            ? '<span style="background:#dcfce7; color:#166534; padding:2px 8px; border-radius:10px; font-size:12px;">Đang làm việc</span>' 
            : '<span style="background:#fee2e2; color:#991b1b; padding:2px 8px; border-radius:10px; font-size:12px;">Nghỉ việc</span>';

        //Xử lý hiển thị
        const tongLuong = salaryMapByEmp[emp.id];
        let tongLuongHtml;
        if (tongLuong === null || tongLuong === undefined) {
            tongLuongHtml = '<span style="color:#9ca3af; font-size:12px; font-style:italic;">Chưa có dữ liệu</span>';
        } else if (tongLuong === 0) {
            tongLuongHtml = '<span style="color:#9ca3af; font-size:12px;">Chưa tính lương</span>';
        } else {
            tongLuongHtml = `<span style="font-weight:600; color:#16a34a;">${tongLuong.toLocaleString('vi-VN')} ₫</span>`;
        }

        // Tạo dòng bảng cho mỗi nhân viên (Trang chi tiết)
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="padding:12px;"><b onclick="openEmployeeDetail(${emp.id})" style="cursor:pointer; color:#2563eb;">NV${emp.id}</b></td>
            <td style="padding:12px;">
                <div style="display:flex; align-items:center; gap:10px;">
                    <img src="${emp.avatar}" style="width:36px; height:36px; border-radius:50%; object-fit: cover;">
                    <div>
                        <div style="font-weight:600;">${emp.name}</div>
                        <div style="font-size:12px; color:#6b7280;">${emp.email}</div>
                    </div>
                </div>
            </td>
            <td style="padding:12px;">${emp.dept}</td>
            <td style="padding:12px;">${emp.role}</td>
            <td style="padding:12px;">${tongLuongHtml}</td>
            <td style="padding:12px;">${statusBadge}</td>
            <td style="padding:12px; text-align: center;">
                <button onclick="openEmployeeDetail(${emp.id})" title="Sửa hồ sơ" style="border:none; background:none; cursor:pointer; color:#2563eb; margin-right:10px;">
                    <i class="fa-solid fa-pen"></i>
                </button>
                <button onclick="deleteEmployee(${emp.id})" title="Xóa" style="border:none; background:none; cursor:pointer; color:#dc2626;">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            </td>
        `;
        tbody.appendChild(tr);
    });

    if(pageInfo) pageInfo.innerText = `Hiển thị ${startIndex + 1}-${endIndex} trên ${totalItems} nhân viên`;
    
    // VẼ PHÂN TRANG
    if(paginationControls) {
        paginationControls.innerHTML = '';
        const btnPrev = document.createElement('button');
        btnPrev.className = `page-btn ${currentPage === 1 ? 'disabled' : ''}`;
        btnPrev.innerHTML = '<i class="fa-solid fa-chevron-left"></i>';
        btnPrev.onclick = () => { if(currentPage > 1) { currentPage--; renderEmployeeTable(data); }};
        paginationControls.appendChild(btnPrev);

        for(let i = 1; i <= totalPages; i++) {
            const btn = document.createElement('button');
            btn.className = `page-btn ${i === currentPage ? 'active' : ''}`;
            btn.innerText = i;
            btn.onclick = () => { currentPage = i; renderEmployeeTable(data); };
            paginationControls.appendChild(btn);
        }

        const btnNext = document.createElement('button');
        btnNext.className = `page-btn ${currentPage >= totalPages ? 'disabled' : ''}`;
        btnNext.innerHTML = '<i class="fa-solid fa-chevron-right"></i>';
        btnNext.onclick = () => { if(currentPage < totalPages) { currentPage++; renderEmployeeTable(data); }};
        paginationControls.appendChild(btnNext);
    }
}

// =============================================================
// 5. THÊM MỚI VÀ SỬA NHÂN VIÊN 
// =============================================================
// Hàm mở modal thêm mới nhân viên
function openEmpModal() {
    const modal = document.getElementById('employeeModal');
    const form = document.getElementById('employeeForm'); 
    if(form) form.reset(); 
    if(modal) modal.style.display = 'flex';
}

function closeEmpModal() {
    document.getElementById('employeeModal').style.display = 'none';
}

// Hàm lưu khi thêm mới nhân viên
function saveEmployee() {
    const name = document.getElementById('empName').value;
    const phone = document.getElementById('empPhone') ? document.getElementById('empPhone').value : '';
    const birth = document.getElementById('empBirth') ? document.getElementById('empBirth').value : null;
    const cccd = document.getElementById('empCCCD') ? document.getElementById('empCCCD').value : '';
    const gender = document.getElementById('empGender') ? document.getElementById('empGender').value : 'Nam';
    const address = document.getElementById('empAddress') ? document.getElementById('empAddress').value : '';

    const idpb_value = document.getElementById('empDept').value;
    const idcv_value = document.getElementById('empRole').value;

    if(!name || !idpb_value || !idcv_value) {
        alert("Vui lòng nhập Tên nhân viên và chọn đầy đủ Phòng ban, Chức vụ!");
        return;
    }

    // Tạo đối tượng nhân viên
    const newEmp = {
        hoTen: name,
        gioiTinh: gender === 'Nam' ? 1 : 0,
        dienThoai: phone,
        ngaySinh: birth,
        cccd: cccd,
        diaChi: address,
        idpb: parseInt(idpb_value),
        idcv: parseInt(idcv_value)
    };

    apiFetch('http://localhost:8080/api/nhan-vien/them', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEmp)
    })
    .then(response => {
        if(response.ok) {
            alert("Đã lưu thành công vào Cơ sở dữ liệu!");
            closeEmpModal();
            loadAllDataFromAPI();
        } else {
            alert("Lỗi khi lưu vào CSDL!");
        }
    })
    .catch(error => console.error("Lỗi:", error));
}
// Hàm lưu khi sửa hồ sơ nhân viên
function saveEmployeeDetail() {
    const id = document.getElementById('detailId').value;
    const name = document.getElementById('detailName').value;
    const phone = document.getElementById('detailPhone') ? document.getElementById('detailPhone').value : '';
    const cccd = document.getElementById('detailCCCD') ? document.getElementById('detailCCCD').value : '';
    const address = document.getElementById('detailAddress') ? document.getElementById('detailAddress').value : '';
    const birth = document.getElementById('detailBirth') ? document.getElementById('detailBirth').value : null;
    
    const idpb_value = document.getElementById('detailDept').value;
    const idcv_value = document.getElementById('detailRole').value;
    const statusVal = document.getElementById('detailStatus')?.value;

    const updatedEmp = {
        hoTen: name,
        dienThoai: phone,
        cccd: cccd,
        diaChi: address,
        ngaySinh: birth,
        idpb: parseInt(idpb_value),
        idcv: parseInt(idcv_value), 
        gioiTinh: 1,
        daThoiViec: (statusVal === 'Leave') ? 1 : 0
    };

    apiFetch(`http://localhost:8080/api/nhan-vien/sua/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedEmp)
    })
    .then(response => {
        if(response.ok) {
            alert("Đã cập nhật hồ sơ thành công vào SQL Server!");
            closeEmployeeDetail();
            loadAllDataFromAPI(); 
        } else {
            alert("Có lỗi xảy ra khi cập nhật!");
        }
    })
    .catch(error => console.error("Lỗi kết nối:", error));
}

// =============================================================
// 6. XÓA NHÂN VIÊN VÀ NGHỈ VIỆC
// =============================================================
function deleteEmployee(id) {
    if(confirm(`Bạn có chắc chắn muốn xóa vĩnh viễn nhân viên NV${id} không?`)) {
        apiFetch(`http://localhost:8080/api/nhan-vien/xoa/${id}`, {
            method: 'DELETE'
        })
        .then(response => {
            if(response.ok) {
                alert("Đã xóa thành công khỏi hệ thống!");
                loadAllDataFromAPI(); 
            }
        })
        .catch(error => console.error("Lỗi xóa:", error));
    }
}

function terminateEmployee() {
    const id = document.getElementById('detailId').value;
    const name = document.getElementById('detailName').value;

    if (confirm(`Bạn có chắc chắn muốn xác nhận nhân viên ${name} nghỉ việc không?`)) {
        apiFetch(`http://localhost:8080/api/nhan-vien/nghi-viec/${id}`, {
            method: 'PUT'
        })
        .then(response => {
            if(response.ok) {
                alert("Đã cập nhật trạng thái nghỉ việc!");
                document.getElementById('detailStatus').value = "Leave";
                loadAllDataFromAPI();
            }
        })
        .catch(error => console.error("Lỗi cập nhật nghỉ việc:", error));
    }
}

// =============================================================
// 7. MỞ HỒ SƠ NHÂN VIÊN VÀ HIỂN THỊ CHI TIẾT, CÙNG LOGIC CHUYỂN TAB TRONG HỒ SƠ
// =============================================================
function openEmployeeDetail(id) {
    const tableSection = document.getElementById('employee-section') || document.getElementById('employeeTableSection'); 
    if(tableSection) tableSection.style.display = 'none';
    
    const detailSection = document.getElementById('employee-detail-section');
    if(detailSection) detailSection.style.display = 'block';

    const emp = listEmployees.find(e => e.id == id);
    if (!emp) return;

    const safeSetText = (id, text) => { const el = document.getElementById(id); if (el) el.innerText = text; };
    const safeSetVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };

    safeSetText('detailIdDisplay', "NV" + emp.id);
    safeSetText('detailNameDisplay', emp.name);
    safeSetText('detailRoleDisplay', emp.role);
    safeSetText('detailEmailDisplay', emp.email || '---');
    safeSetText('detailPhoneDisplay', emp.phone || '---');

    const avatar = document.getElementById('detailAvatar');
    if (avatar) avatar.src = emp.avatar;

    safeSetVal('detailId', emp.id);
    safeSetVal('detailName', emp.name);
    safeSetVal('detailDept', emp.idpb);
    safeSetVal('detailRole', emp.idcv);
    safeSetVal('detailStatus', emp.status);

    const fields = ['CCCD', 'Birth', 'Phone', 'Email', 'Address'];
    fields.forEach(f => {
        safeSetVal('detail' + f, emp[f.toLowerCase()] || '');
    });

    loadSalaryData(); 

    setTimeout(() => {
        safeSetVal('detailStatus', emp.status === 'Active' ? 'Active' : 'Leave');
    }, 100);

    switchTab('tabInfo'); 
}

function closeEmployeeDetail() {
    document.getElementById('employee-detail-section').style.display = 'none';
    const tableSection = document.getElementById('employee-section') || document.getElementById('employeeTableSection');
    if(tableSection) tableSection.style.display = 'block';
}

//xử lý logic lọc nhân viên
function handleSearchFilter() {
    const searchInput = document.getElementById('searchEmp'); 
    const deptSelect = document.getElementById('filterDept');
    
    const keyword = searchInput ? searchInput.value.toLowerCase().trim() : "";
    const deptId = deptSelect ? deptSelect.value : ""; 

    const filtered = listEmployees.filter(emp => {
        const nameStr = String(emp.name || "").toLowerCase();
        const idStr = String("nv" + emp.id).toLowerCase();
        
        const matchText = keyword === "" || 
                  nameStr.includes(keyword) ||
                  idStr.includes(keyword);
        
        const matchDept = (deptId === "") || 
                          (String(emp.idpb) === String(deptId)) || 
                          (String(emp.dept) === String(deptId));
        
        return matchText && matchDept;
    });
    
    //  reset trang về 1 khi có filter mới, sau đó sort nếu đang có trạng thái sort
    currentPage = 1;
    if (sortOrder === 'asc') {
        filtered.sort((a, b) => (salaryMapByEmp[a.id] || 0) - (salaryMapByEmp[b.id] || 0));
    } else if (sortOrder === 'desc') {
            filtered.sort((a, b) => (salaryMapByEmp[b.id] || 0) - (salaryMapByEmp[a.id] || 0));
    }
    renderEmployeeTable(filtered);
}

function loadOptionsToSelect() {
    let deptHtml = '<option value="">-- Chọn phòng ban --</option>';
    danhSachPhongBan.forEach(pb => {
        deptHtml += `<option value="${pb.idpb}">${pb.tenPB}</option>`;
    });

    let roleHtml = '<option value="">-- Chọn chức vụ --</option>';
    danhSachChucVu.forEach(cv => {
        roleHtml += `<option value="${cv.idcv}">${cv.tenCV}</option>`;
    });

    // Đổ dữ liệu phòng ban và chức vụ dropdown ở cả form thêm mới, sửa chi tiết và filter
    const addDeptSelect = document.getElementById('empDept');
    const editDeptSelect = document.getElementById('detailDept');
    const filterDeptSelect = document.getElementById('filterDept');
    const addRoleSelect = document.getElementById('empRole');
    const editRoleSelect = document.getElementById('detailRole');

    if (addDeptSelect) addDeptSelect.innerHTML = deptHtml;
    if (editDeptSelect) editDeptSelect.innerHTML = deptHtml;
    if (filterDeptSelect) {
        filterDeptSelect.innerHTML = `<option value="">Tất cả phòng ban</option>` + deptHtml.replace('<option value="">-- Chọn phòng ban --</option>', '');
    }
    if (addRoleSelect) addRoleSelect.innerHTML = roleHtml;
    if (editRoleSelect) editRoleSelect.innerHTML = roleHtml;
}

// =============================================================
// 8. LOGIC CHUYỂN TAB
// =============================================================
function switchTab(tabId, element) {
    document.querySelectorAll('.tab-content').forEach(sec => {
        sec.classList.remove('active-tab');
    });

    const target = document.getElementById(tabId);
    if (target) target.classList.add('active-tab');

    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    if (element) {
        element.classList.add('active');
    } else {
        const btn = Array.from(document.querySelectorAll('.tab-btn'))
            .find(b => b.getAttribute('onclick')?.includes(tabId));
        if (btn) btn.classList.add('active');
    }
}

// =============================================================
// 9. HÀM TÍNH LƯƠNG TRONG HỒ SƠ
// =============================================================
function loadSalaryData() {
    const id = document.getElementById('detailId')?.value;
    if (!id) return;

    Promise.all([
        apiFetch('http://localhost:8080/api/hop-dong/danh-sach').then(r => r.json()),
        apiFetch('http://localhost:8080/api/chuc-vu/danh-sach').then(r => r.json())
    ]).then(([danhSachHD, danhSachCV]) => {
        const hd = danhSachHD.find(h => String(h.maNV) === String(id) && h.trangThai === 1);
        
        const salary = hd ? (hd.luongCoBan || 0) : 0;
        const phuCapHD = hd ? (hd.phuCap || 0) : 0;

        const emp = listEmployees.find(e => String(e.id) === String(id));
        const cv = emp ? danhSachCV.find(c => String(c.idcv) === String(emp.idcv)) : null;
        const phuCapCV = cv ? (cv.phuCap || 0) : 0;

        const tongPhuCap = phuCapHD + phuCapCV;

        const salaryInput = document.getElementById('profileBaseSalary');
        const allowanceInput = document.getElementById('profileAllowance');
        const displayTotal = document.getElementById('expectedIncomeDisplay');

        // Hiển thị lương cơ bản, phụ cấp và tổng lương
        if (salaryInput) salaryInput.value = salary.toLocaleString('vi-VN') + " VNĐ";
        if (allowanceInput) allowanceInput.value = tongPhuCap.toLocaleString('vi-VN') + " VNĐ";
        if (displayTotal) displayTotal.innerText = (salary + tongPhuCap).toLocaleString('vi-VN') + " VNĐ";
    });
}

// =============================================================
// 10. BIỂU ĐỒ LƯƠNG THEO THÁNG TRONG NĂM
// =============================================================
let salaryChartInstance = null; 

function loadSalaryChart() {
    const id = document.getElementById('detailId')?.value;
    if (!id) return;

    const yearSelect = document.getElementById('salaryChartYear');
    const nam = yearSelect ? yearSelect.value : new Date().getFullYear();

    // Hiển thị loading và ẩn canvas trong khi chờ dữ liệu
    const loadingEl = document.getElementById('salaryChartLoading');
    const canvas = document.getElementById('salaryByMonthChart');
    if (!canvas) return;

    if (loadingEl) loadingEl.style.display = 'block';
    canvas.style.display = 'none';

    if (salaryChartInstance) {
        salaryChartInstance.destroy();
        salaryChartInstance = null;
    }

    apiFetch(`http://localhost:8080/api/bang-luong/theo-nam?maNV=${id}&nam=${nam}`)
        .then(res => res.json())
        .then(data => {
            if (loadingEl) loadingEl.style.display = 'none';
            canvas.style.display = 'block';

            const luongThang = Array(12).fill(0);
            data.forEach(item => {
                if (item.thang >= 1 && item.thang <= 12) {
                    luongThang[item.thang - 1] = item.total || 0;
                }
            });

            const labels = ['T1','T2','T3','T4','T5','T6','T7','T8','T9','T10','T11','T12'];
            const barColors = luongThang.map(v => v > 0 ? '#3b82f6' : '#e5e7eb');

            salaryChartInstance = new Chart(canvas.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Thực lãnh (VNĐ)',
                        data: luongThang,
                        backgroundColor: barColors,
                        borderRadius: 6,
                        borderSkipped: false,
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                title: ctx => `Tháng ${ctx[0].label.replace('T','')} — ${nam}`,//
                                label: ctx => {
                                    if (ctx.parsed.y === 0) return '  Chưa tính lương';
                                    return '  ' + ctx.parsed.y.toLocaleString('vi-VN') + ' VNĐ';
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: val => {
                                    if (val >= 1_000_000) return (val / 1_000_000).toFixed(0) + 'M';
                                    return val;
                                }
                            },
                            grid: { color: '#f5f5f5' }
                        },
                        x: { grid: { display: false } }
                    }
                }
            });
        })
        .catch(err => {
            if (loadingEl) loadingEl.style.display = 'none';
            canvas.style.display = 'block';
            console.error('Lỗi load biểu đồ lương:', err);
        });
}

function initSalaryChartYearSelect() {
    const yearSelect = document.getElementById('salaryChartYear');
    if (!yearSelect) return;

    const currentYear = new Date().getFullYear();
    yearSelect.innerHTML = '';

    for (let y = currentYear; y >= currentYear - 4; y--) {
        const opt = document.createElement('option');
        opt.value = y;
        opt.text = `Năm ${y}`;
        if (y === currentYear) opt.selected = true;
        yearSelect.appendChild(opt);
    }

    yearSelect.addEventListener('change', loadSalaryChart);
}

// =============================================================
// 11. TỔNG LƯƠNG THEO NĂM TRONG BẢNG DANH SÁCH 
// =============================================================
function loadAllSalariesForYear(year) {
    if (!listEmployees || listEmployees.length === 0) return Promise.resolve();

    const promises = listEmployees.map(emp =>
        apiFetch(`http://localhost:8080/api/bang-luong/theo-nam?maNV=${emp.id}&nam=${year}`)
            .then(r => r.json())
            .then(data => {
                const total = Array.isArray(data)
                    ? data.reduce((sum, item) => sum + (item.total || 0), 0)
                    : 0;
                salaryMapByEmp[emp.id] = total;
            })
            .catch(() => { salaryMapByEmp[emp.id] = null; }) 
    );

    return Promise.all(promises);
}

function handleYearFilter() {
    const yearSelect = document.getElementById('filterYear');
    if (!yearSelect) return;
    selectedYear = parseInt(yearSelect.value);

    const thTongLuong = document.getElementById('thTongLuong');
    if (thTongLuong) thTongLuong.innerText = `TỔNG LƯƠNG ${selectedYear}`;

    loadAllSalariesForYear(selectedYear).then(() => {
        handleSearchFilter();
    });
}

function toggleSortSalary() {
    if (sortOrder === null) sortOrder = 'asc';
    else if (sortOrder === 'asc') sortOrder = 'desc';
    else sortOrder = null;

    const sortIcon = document.getElementById('sortIcon');
    if (sortIcon) {
        if (sortOrder === 'asc') sortIcon.innerText = '↑';
        else if (sortOrder === 'desc') sortIcon.innerText = '↓';
        else sortIcon.innerText = '⇅';
    }

    handleSearchFilter();
}






















//// =============================================================
// API BACKEND ĐƯỢC GỌI TRONG FILE NÀY
// =============================================================
// 1. loadAllDataFromAPI()
//    - GET /api/phong-ban/danh-sach       → PhongBanRepository
//    - GET /api/chuc-vu/danh-sach         → ChucVuRepository
//    - GET /api/nhan-vien/danh-sach       → NhanVienRepository
//
// 2. saveEmployee() - Thêm mới nhân viên
//    - POST /api/nhan-vien/them            → NhanVienRepository
//
// 3. saveEmployeeDetail() - Sửa hồ sơ
//    - PUT /api/nhan-vien/sua/{id}         → NhanVienRepository
//
// 4. deleteEmployee() - Xóa nhân viên
//    - DELETE /api/nhan-vien/xoa/{id}      → NhanVienRepository
//
// 5. terminateEmployee() - Nghỉ việc
//    - PUT /api/nhan-vien/nghi-viec/{id}   → NhanVienRepository
//
// 6. loadSalaryData() - Xem lương trong hồ sơ
//    - GET /api/hop-dong/danh-sach         → HopDongRepository
//    - GET /api/chuc-vu/danh-sach          → ChucVuRepository
//
// 7. loadSalaryChart() & loadAllSalariesForYear() - Biểu đồ & tổng lương
//    - GET /api/bang-luong/theo-nam?maNV={id}&nam={year} → BangLuongRepository
// =============================================================