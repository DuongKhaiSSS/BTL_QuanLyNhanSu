/* global listEmployees, danhSachPhongBan, danhSachChucVu */
/* eslint-disable no-unused-vars */

// =============================================================
// 1. KHỞI TẠO BIẾN TOÀN CỤC (QUẢN LÝ TRẠNG THÁI)
// =============================================================
let currentMonthAttendance = []; // Dữ liệu bảng công của tháng đang chọn
let listOvertime = [];           // Danh sách tăng ca lấy từ SQL
let listLoaiCa = [];             // Danh sách hệ số lương (x1.5, x2.0, x3.0)
let danhSachHD = [];             // Danh sách hợp đồng dùng chung

// =============================================================
// 2. ĐIỀU HƯỚNG GIAO DIỆN (TAB CONTROL)
// =============================================================
function switchTimekeepingTab(tab) {
    const dailyTab = document.getElementById('tab-daily-work');
    const otTab = document.getElementById('tab-overtime');

    if (tab === 'daily') {
        if(dailyTab) dailyTab.style.display = 'block';
        if(otTab) otTab.style.display = 'none';
        loadTimekeepingData();
    } else {
        if(dailyTab) dailyTab.style.display = 'none';
        if(otTab) otTab.style.display = 'block';
        loadOvertimeData();
    }
}

// Hàm khởi tạo khi bấm vào menu chính
async function showTimekeepingSection() {
    // Ẩn tất cả section khác, chỉ hiển thị section chấm công
    document.querySelectorAll('.content-body').forEach(s => s.style.display = 'none');
    const tkSection = document.getElementById('timekeeping-section');
    if (tkSection) tkSection.style.display = 'block';

    // Đánh dấu menu chấm công đang active
    document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
    const menuBtn = document.getElementById('menu-chamcong');
    if (menuBtn) menuBtn.classList.add('active');

    await loadAllDataFromAPI();

    await Promise.all([
        loadTimekeepingData(),
        loadLoaiCaFromAPI()
    ]);

    const filterDeptCC = document.getElementById('filterDeptChamCong');
    filterDeptCC.innerHTML = '<option value="">Tất cả phòng ban</option>';
    danhSachPhongBan.forEach(pb => {
        const opt = document.createElement('option');
        opt.value = pb.idpb;
        opt.textContent = pb.tenPB;
        filterDeptCC.appendChild(opt);
    });
}

// =============================================================
// 3. CHẤM CÔNG HÀNG THÁNG (Bảng tb_BANGCONG)
// =============================================================
async function loadTimekeepingData() {
    const period = document.getElementById('tkMonth').value;
    const tbody = document.getElementById('tkTableBody');
    if (!tbody) return;

    // Đảm bảo đã có dữ liệu nhân viên trước khi xử lý bảng công
    try {
        if (!listEmployees || listEmployees.length === 0) {
            await new Promise((resolve) => {
                const check = setInterval(() => {
                    if (listEmployees && listEmployees.length > 0) {
                        clearInterval(check);
                        resolve();
                    }
                }, 100);
            });
        }

        const parts = period.split("-");
        const nam = parseInt(parts[0]);
        const thang = parseInt(parts[1]);

        // Tính số ngày công mặc định dựa trên ngày bắt đầu hợp đồng và số ngày trong tháng
        const firstDayOfMonth = new Date(nam, thang - 1, 1);
        const lastDayOfMonth = new Date(nam, thang, 0);
        const totalDaysInMonth = lastDayOfMonth.getDate();

        const [dbDataRes, hdRes] = await Promise.all([
            apiFetch(`http://localhost:8080/api/bang-cong/lay-theo-thang?period=${period}`),
            apiFetch(`http://localhost:8080/api/hop-dong/danh-sach`)
        ]);
        const dbData = await dbDataRes.json();
        danhSachHD = await hdRes.json();

        currentMonthAttendance = listEmployees
            .filter(e => e.status === 'Active')
            // Lọc nhân viên có hợp đồng đang hoạt động và bắt đầu trước hoặc trong tháng này
            .filter(emp => {
                const hd = danhSachHD.find(h =>
                    String(h.maNV) === String(emp.id) && h.trangThai === 1
                );
                // Nếu không có hợp đồng hoặc hợp đồng bắt đầu sau tháng này thì không hiển thị
                if (!hd) return false;
                const [hy, hm, hd2] = hd.ngayBatDau.split('-').map(Number);
                const ngayBD = new Date(hy, hm - 1, hd2);
                return ngayBD <= lastDayOfMonth;
            })
            .map(emp => {
                const saved = dbData.find(d => d.maNV === emp.id);
                const hd = danhSachHD.find(h =>
                    String(h.maNV) === String(emp.id) && h.trangThai === 1
                );
                // Tính số ngày công mặc định dựa trên ngày bắt đầu hợp đồng
                let defaultWorkDays = 26;
                if (hd) {
                    const [hy, hm, hd2] = hd.ngayBatDau.split('-').map(Number);
                    const ngayBD = new Date(hy, hm - 1, hd2);
                    if (ngayBD >= firstDayOfMonth && ngayBD <= lastDayOfMonth) {
                        let workDayCount = 0;
                        for (let d = ngayBD.getDate(); d <= totalDaysInMonth; d++) {
                            const dow = new Date(nam, thang - 1, d).getDay();
                            if (dow !== 0 && dow !== 6) workDayCount++;
                        }
                        defaultWorkDays = workDayCount;
                    }
                }

                return {
                    staffId: emp.id,
                    name: emp.name,
                    role: emp.role,
                    dept: emp.dept,
                    idpb: emp.idpb,
                    workDays: saved ? saved.ngayCongThucTe : defaultWorkDays,
                    leaveDays: saved ? saved.ngayNghiPhep : 0
                };
            });

        renderTimekeepingTable(currentMonthAttendance);
    } catch (err) {
        console.error("Lỗi tải chấm công:", err);
    }
}

// Hàm hiển thị dữ liệu bảng công ra giao diện
function renderTimekeepingTable(data) {
    const tbody = document.getElementById('tkTableBody');
    tbody.innerHTML = '';

    if (data.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding: 20px;">Không có dữ liệu nhân viên</td></tr>';
        return;
    }

    data.forEach(item => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><b>NV${item.staffId}</b></td>
            <td>${item.name}</td>
            <td>${item.role}</td>
            <td style="text-align: center;">
                <input type="number" class="work-input" data-id="${item.staffId}" 
                       value="${item.workDays}" min="0" max="31"
                       style="width: 80px; text-align: center; font-weight: bold; color: #2563eb;">
            </td>
            <td style="text-align: center;">
                <input type="number" class="leave-input" data-id="${item.staffId}" 
                       value="${item.leaveDays}" min="0" max="31"
                       style="width: 80px; text-align: center;">
            </td>
            <td><span class="badge-working" style="background:#dcfce7; color:#166534; padding:2px 8px; border-radius:10px; font-size:12px;">Đang làm việc</span></td>
        `;
        tbody.appendChild(tr);
    });
}

// Hàm lưu bảng công vào SQL Server
function saveTimekeeping() {
    const period = document.getElementById('tkMonth').value;
    const parts = period.split("-");
    const nam = parseInt(parts[0]);
    const thang = parseInt(parts[1]);

    const workInputs = document.querySelectorAll('.work-input');// Lấy tất cả input ngày công thực tế
    const leaveInputs = document.querySelectorAll('.leave-input');// Lấy tất cả input ngày nghỉ phép
    
    const dataToSave = [];
    for (let i = 0; i < workInputs.length; i++) {
        const val = parseFloat(workInputs[i].value);
        const lVal = parseFloat(leaveInputs[i].value);
        
        if (val < 0 || val > 31 || lVal < 0) {
            alert(`Dữ liệu của NV${workInputs[i].dataset.id} không hợp lệ!`);
            return;
        }

        dataToSave.push({
            maNV: parseInt(workInputs[i].dataset.id),
            nam: nam,
            thang: thang,
            ngayCongTrongThang: 26,
            ngayCongThucTe: val,
            ngayNghiPhep: lVal,
            ngayKhongPhep: 0
        });
    }

    // 1
    apiFetch('http://localhost:8080/api/bang-cong/luu-danh-sach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dataToSave)
    }).then(res => {
        if(res.ok) alert(`🎉 Đã lưu bảng công tháng ${thang}/${nam} vào SQL Server!`);
    });
}

// =============================================================
// 4. QUẢN LÝ TĂNG CA (Bảng tb_TANGCA & tb_LOAICA)
// =============================================================
async function loadLoaiCaFromAPI() {
    try {
        const res = await apiFetch('http://localhost:8080/api/loai-ca/danh-sach');
        listLoaiCa = await res.json();
    } catch (e) { console.error("Lỗi tải loại ca:", e); }
}

// Hàm tải dữ liệu tăng ca từ SQL Server và hiển thị ra bảng
async function loadOvertimeData() {
    const tbody = document.getElementById('otTableBody');
    if (!tbody) return;

    try {
        const res = await apiFetch('http://localhost:8080/api/tang-ca/danh-sach');
        listOvertime = await res.json();

        const period = document.getElementById('tkMonth').value;
        const [nam, thang] = period.split('-').map(Number);

        // Lọc tăng ca chỉ của tháng đang chọn và sắp xếp theo ngày giảm dần
        const filtered = listOvertime.filter(ot => ot.nam === nam && ot.thang === thang);
        filtered.sort((a, b) => b.ngay - a.ngay);

        tbody.innerHTML = '';
        // Nếu không có dữ liệu tăng ca nào cho tháng này, hiển thị thông báo
        if (filtered.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:20px;">Không có dữ liệu tăng ca tháng ' + thang + '/' + nam + '</td></tr>';
            return;
        }

        // Hiển thị dữ liệu tăng ca đã lọc ra bảng
        filtered.forEach(ot => {
            const emp = listEmployees.find(e => e.id === ot.maNV);
            const lc = listLoaiCa.find(l => l.idLoaiCa === ot.idLoaiCa);
            // Hiển thị ngày đầy đủ dạng dd/mm/yyyy
            const ngayHienThi = `${String(ot.ngay).padStart(2,'0')}/${String(ot.thang).padStart(2,'0')}/${ot.nam}`;
            tbody.innerHTML += `
                <tr>
                    <td>${ngayHienThi}</td>
                    <td><b>${emp ? emp.name : 'NV' + ot.maNV}</b></td>
                    <td><b>${ot.soGio}h</b></td>
                    <td>${lc ? lc.tenLoaiCa : 'Tăng ca'}</td>
                    <td>x${lc ? lc.heSo : '1.5'}</td>
                    <td style="text-align: center;">
                        <button class="delete-btn" onclick="deleteOvertime(${ot.id})" style="border:none; background:none; color:#dc2626; cursor:pointer;">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </td>
                </tr>`;
        });
    } catch (err) { console.error("Lỗi tải tăng ca:", err); }
}

function openOvertimeModal() {
    const selectStaff = document.getElementById('otStaff');
    const selectType = document.getElementById('otType');

    // Chỉ hiển thị nhân viên đang hoạt động và có hợp đồng bắt đầu trước hoặc trong tháng này
    if (selectStaff) {
        selectStaff.innerHTML = listEmployees.filter(e => e.status === 'Active')
            .map(e => `<option value="${e.id}">${e.id} - ${e.name}</option>`).join('');
    }

    if (selectType) {
        selectType.innerHTML = listLoaiCa
            .filter(l => l.idLoaiCa && l.tenLoaiCa && typeof l.tenLoaiCa === 'string' && l.heSo > 0)
            .map(l => `<option value="${l.idLoaiCa}">${l.tenLoaiCa} (x${l.heSo})</option>`).join('');
    }

    const modal = document.getElementById('overtimeModal');
    if (modal) modal.style.display = 'flex';
    document.getElementById('otDate').valueAsDate = new Date();
}

function saveOvertime() {
    const maNV = parseInt(document.getElementById('otStaff').value);
    const ngay = document.getElementById('otDate').value; // "2026-03-05"
    const soGio = parseFloat(document.getElementById('otHours').value);
    const idLoaiCa = parseInt(document.getElementById('otType').value);

    // 1. Giờ hợp lệ
    if (soGio <= 0 || soGio > 8) { alert("Giờ tăng ca phải từ 0.5 - 8h!"); return; }

    // 2. Parse ngày đúng cách tránh lệch timezone
    const [yyyy, mm, dd] = ngay.split('-').map(Number);
    const selectedDate = new Date(yyyy, mm - 1, dd);

    const today = new Date(); today.setHours(0,0,0,0);

    // 3. Không quá 7 ngày trong tương lai
    const maxFuture = new Date();
    maxFuture.setDate(maxFuture.getDate() + 7);
    if (selectedDate > maxFuture) { alert("Chỉ được đăng ký tăng ca trước tối đa 7 ngày!"); return; }

    // 4. Không quá 30 ngày trước
    const minDate = new Date();
    minDate.setDate(minDate.getDate() - 30);
    if (selectedDate < minDate) { alert("Chỉ được đăng ký tăng ca trong vòng 30 ngày gần nhất!"); return; }

    // 5. Không trùng ngày của cùng nhân viên
    const trung = listOvertime.find(ot =>
        ot.maNV === maNV &&
        ot.ngay === dd &&
        ot.thang === mm &&
        ot.nam === yyyy
    );
    if (trung) { alert("Nhân viên này đã có tăng ca trong ngày " + dd + "/" + mm + "/" + yyyy + "!"); return; }

    // 6. Không được tăng ca trước ngày vào làm
    const hdNV = danhSachHD.find(h => String(h.maNV) === String(maNV) && h.trangThai === 1);
    if (hdNV) {
        const [hy, hm, hd2] = hdNV.ngayBatDau.split('-').map(Number);
        const ngayVaoLam = new Date(hy, hm - 1, hd2);
        if (selectedDate < ngayVaoLam) {
            alert("Không được đăng ký tăng ca trước ngày vào làm (" + hdNV.ngayBatDau + ")!");
            return;
        }
    }

    // 7. Tổng giờ tháng không quá 40h
    const tongGio = listOvertime
        .filter(ot => ot.maNV === maNV && ot.thang === mm && ot.nam === yyyy)
        .reduce((sum, ot) => sum + ot.soGio, 0);
    if (tongGio + soGio > 40) { alert(`Tổng tăng ca tháng ${mm}/${yyyy} vượt quá 40h! Hiện tại: ${tongGio}h`); return; }

    const newOT = { maNV, ngay: dd, soGio, idLoaiCa, nam: yyyy, thang: mm };

    apiFetch('http://localhost:8080/api/tang-ca/them', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOT)
    }).then(res => {
        if (res.ok) {
            alert("Đã thêm tăng ca thành công!");
            document.getElementById('overtimeModal').style.display = 'none';
            loadOvertimeData();
        } else {
            res.text().then(t => console.log("Lỗi backend:", t));
        }
    });
}

function deleteOvertime(id) {
    if(confirm("Xóa dòng tăng ca này khỏi SQL Server?")) {
        apiFetch(`http://localhost:8080/api/tang-ca/xoa/${id}`, { method: 'DELETE' })
        .then(() => loadOvertimeData());
    }
}

// =============================================================
// 5. TÌM KIẾM & LỌC PHÒNG BAN
// =============================================================
function handleSearchChamCong() {
    const keyword = document.getElementById('searchChamCong').value.toLowerCase().trim();
    const deptId = document.getElementById('filterDeptChamCong').value;

    const otTab = document.getElementById('tab-overtime');
    const isOtTabVisible = otTab && otTab.style.display !== 'none';

    if (isOtTabVisible) {
        const filtered = listOvertime.filter(ot => {
            const emp = listEmployees.find(e => e.id === ot.maNV);
            const nameStr = String(emp ? emp.name : '').toLowerCase();
            const idStr = String('nv' + ot.maNV).toLowerCase();
            const empIdpb = String(emp ? emp.idpb : '');

            const matchText = keyword === '' || nameStr.includes(keyword) || idStr.includes(keyword);
            const matchDept = deptId === '' || empIdpb === String(deptId);
            return matchText && matchDept;
        });

        const tbody = document.getElementById('otTableBody');
        tbody.innerHTML = '';
        filtered.forEach(ot => {
            const emp = listEmployees.find(e => e.id === ot.maNV);
            const lc = listLoaiCa.find(l => l.idLoaiCa === ot.idLoaiCa);
            const ngayHienThi = `${String(ot.ngay).padStart(2,'0')}/${String(ot.thang).padStart(2,'0')}/${ot.nam}`;
            tbody.innerHTML += `
                <tr>
                    <td>${ngayHienThi}</td>
                    <td><b>${emp ? emp.name : 'NV' + ot.maNV}</b></td>
                    <td><b>${ot.soGio}h</b></td>
                    <td>${lc ? lc.tenLoaiCa : 'Tăng ca'}</td>
                    <td>x${lc ? lc.heSo : '1.5'}</td>
                    <td style="text-align:center;">
                        <button onclick="deleteOvertime(${ot.id})" style="border:none; background:none; color:#dc2626; cursor:pointer;">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </td>
                </tr>`;
        });
    } else {
        const filtered = currentMonthAttendance.filter(item => {
            const nameStr = String(item.name || "").toLowerCase();
            const idStr = String("nv" + item.staffId).toLowerCase();
            const deptIdStr = String(item.idpb || "");

            const matchText = nameStr.includes(keyword) || idStr.includes(keyword);
            const matchDept = (deptId === "") || (deptIdStr === String(deptId));
            return matchText && matchDept;
        });
        renderTimekeepingTable(filtered);
    }
}

// =============================================================
// 6. KHỞI CHẠY KHI TẢI TRANG
// =============================================================
document.addEventListener("DOMContentLoaded", function() {
    const tkMonthInput = document.getElementById('tkMonth');
    if (tkMonthInput) {
        tkMonthInput.value = "2026-04";
        tkMonthInput.addEventListener('change', () => {
            loadTimekeepingData();
            const otTab = document.getElementById('tab-overtime');
            if (otTab && otTab.style.display !== 'none') loadOvertimeData();
        });
    }
});

function closeOvertimeModal() {
    const modal = document.getElementById('overtimeModal');
    if (modal) modal.style.display = 'none';
}














// =============================================================
// API BACKEND ĐƯỢC GỌI TRONG FILE NÀY
// =============================================================
// 1. loadTimekeepingData() - Tải bảng công theo tháng
//    - GET /api/bang-cong/lay-theo-thang?period={period} → BangCongController
//    - GET /api/hop-dong/danh-sach                       → HopDongController
//
// 2. saveTimekeeping() - Lưu bảng công
//    - POST /api/bang-cong/luu-danh-sach                 → BangCongController
//
// 3. loadLoaiCaFromAPI() - Tải danh sách loại ca
//    - GET /api/loai-ca/danh-sach                        → LoaiCaController
//
// 4. loadOvertimeData() - Tải danh sách tăng ca
//    - GET /api/tang-ca/danh-sach                        → TangCaController
//
// 5. saveOvertime() - Thêm tăng ca
//    - POST /api/tang-ca/them                            → TangCaController
//
// 6. deleteOvertime() - Xóa tăng ca
//    - DELETE /api/tang-ca/xoa/{id}                      → TangCaController
//
// 7. showTimekeepingSection() - Dùng chung từ nhanvien.js loadAllDataFromAPI()
//    - GET /api/phong-ban/danh-sach                      → PhongBanController
//    - GET /api/chuc-vu/danh-sach                        → ChucVuController
//    - GET /api/nhan-vien/danh-sach                      → NhanVienController
// =============================================================