// Biến toàn cục để lưu dữ liệu từ API
let listContracts = [];
let ct_Page = 1;
const ct_Limit = 10;

// =============================================================
// 1. KẾT NỐI API: LẤY CẢ HỢP ĐỒNG VÀ NHÂN VIÊN
// =============================================================
async function loadContractsFromAPI() {
    try {
        const [resHD, resNV] = await Promise.all([
            apiFetch('http://localhost:8080/api/hop-dong/danh-sach'),
            apiFetch('http://localhost:8080/api/nhan-vien/danh-sach')
        ]);

        if (!resHD.ok || !resNV.ok) throw new Error("Lỗi khi tải dữ liệu từ máy chủ!");

        listContracts = await resHD.json();
        listEmployees = await resNV.json();

        // Sắp xếp hợp đồng theo ngày ký (mới nhất lên đầu)
        listContracts.sort((a, b) => new Date(b.ngayKy) - new Date(a.ngayKy));

        // Load phòng ban vào dropdown lọc
        const filterDept = document.getElementById('filterDeptContract');
        if (filterDept && danhSachPhongBan.length > 0) {
            filterDept.innerHTML = '<option value="">Tất cả phòng ban</option>';
            danhSachPhongBan.forEach(pb => {
                filterDept.innerHTML += `<option value="${pb.idpb}">${pb.tenPB}</option>`;
            });
        }
        
        renderContractTable(listContracts);
    } catch (error) {
        console.error("Lỗi API:", error);
        document.getElementById('ct-TableBody').innerHTML = 
            '<tr><td colspan="7" style="text-align:center; color:red;">Không thể kết nối đến máy chủ!</td></tr>';
    }
}

// =============================================================
// 2. HIỂN THỊ DỮ LIỆU HỢP ĐỒNG VÀ PHÂN TRANG
// =============================================================
function renderContractTable(data = listContracts) {
    const tbody = document.getElementById('ct-TableBody'); 
    if (!tbody) return;

    const totalItems = data.length;
    const totalPages = Math.ceil(totalItems / ct_Limit) || 1;

    if (ct_Page > totalPages) ct_Page = totalPages;
    if (ct_Page < 1) ct_Page = 1;

    const startIndex = (ct_Page - 1) * ct_Limit;
    const dataDisplay = data.slice(startIndex, startIndex + ct_Limit);

    tbody.innerHTML = '';

    if (totalItems === 0) {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding: 20px;">Dữ liệu đang trống...</td></tr>';
        document.getElementById('ct-Pagination').innerHTML = '';
        return;
    }

    dataDisplay.forEach(ct => {
        // --- LOGIC TÌM TÊN NHÂN VIÊN ---
        // Tìm nhân viên trong listEmployees có mã trùng với mã trong hợp đồng
        // Nếu tìm thấy, lấy tên, nếu không, hiển thị "Nhân viên [mã]"
        const emp = listEmployees.find(e => e.maNV == ct.maNV); 
        const empName = emp ? emp.hoTen : "Nhân viên " + ct.maNV;  

        let statusBadge = ct.trangThai === 1 
            ? '<span class="badge-working">Hiệu lực</span>' 
            : '<span class="badge-leave">Hết hạn</span>';

        const tr = document.createElement('tr');
        if (ct.trangThai === 0) tr.style.opacity = '0.6'; 

        tr.innerHTML = `
            <td><b>${ct.sohd}</b></td>
            <td>${empName}</td>
            <td>${ct.ngayBatDau} đến ${ct.ngayKetThuc || 'N/A'}</td>
            <td>${Number(ct.luongCoBan).toLocaleString()} VNĐ</td>
            <td>${ct.heSoLuong || 1.0}</td>
            <td>${statusBadge}</td>
            <td style="text-align: center;">
                <button class="action-icon-btn danger" title="Giải quyết thôi việc" onclick="openResignFromContract(${ct.maNV})"><i class="fa-solid fa-user-slash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });

    drawPaginationButtons(totalPages);
}

// Hàm vẽ các nút phân trang
function drawPaginationButtons(totalPages) {
    const container = document.getElementById('ct-Pagination'); 
    if (!container) return;

    container.style.display = 'flex';
    container.style.gap = '8px';
    container.style.justifyContent = 'flex-end';
    container.style.marginTop = '15px';

    let html = '';

    html += `<button class="page-btn" ${ct_Page === 1 ? 'disabled' : ''} onclick="changeCtPage(${ct_Page - 1})">
                <i class="fa-solid fa-chevron-left"></i>
             </button>`;
    
    for (let i = 1; i <= totalPages; i++) {
        html += `<button class="page-btn ${i === ct_Page ? 'active' : ''}" onclick="changeCtPage(${i})">${i}</button>`;
    }
    
    html += `<button class="page-btn" ${ct_Page === totalPages ? 'disabled' : ''} onclick="changeCtPage(${ct_Page + 1})">
                <i class="fa-solid fa-chevron-right"></i>
             </button>`;
    
    container.innerHTML = html;
}

function changeCtPage(page) {
    ct_Page = page;
    renderContractTable();
}

// =============================================================
// 3. XỬ LÝ SỰ KIỆN: KÝ HỢP ĐỒNG MỚI, THÔI VIỆC
// =============================================================
async function saveContract() {
    const staffEl = document.getElementById('ctStaff');
    const numEl = document.getElementById('ctNum');
    const fromEl = document.getElementById('ctFrom');
    const toEl = document.getElementById('ctTo');
    const salaryEl = document.getElementById('ctSalary');
    const rateEl = document.getElementById('ctRate');

    // Nếu các ô nhập liệu bị thiếu trên giao diện, báo lỗi ngay
    if(!staffEl || !numEl || !fromEl || !toEl || !salaryEl) {
        alert("Lỗi giao diện: Không tìm thấy ô nhập liệu!");
        return;
    }

    const rawMaNV = staffEl.value;
    const sohd = numEl.value;
    const from = fromEl.value;
    const to = toEl.value;
    const luong = parseFloat(salaryEl.value);
    const heSo = rateEl ? parseFloat(rateEl.value) : 1.0;

    if (!rawMaNV) { alert("Vui lòng chọn nhân viên!"); return; }
    
    // Ép kiểu về số nguyên, xóa mọi chữ cái
    const cleanMaNV = parseInt(rawMaNV.toString().replace(/\D/g, ''), 10); 

    if (isNaN(cleanMaNV) || cleanMaNV === 0) {
        alert("Lỗi: Mã nhân viên không hợp lệ (Không tìm thấy số)!"); 
        return;
    }

    if (!sohd) { alert("Vui lòng nhập số hợp đồng!"); return; }
    if (luong <= 0 || isNaN(luong)) { alert("Lương cơ bản phải lớn hơn 0!"); return; }
    if (!from || !to) { alert("Vui lòng chọn đầy đủ ngày bắt đầu và kết thúc!"); return; }

    // 2. Tạo đối tượng payload để gửi lên API
    const payload = {
        "sohd": sohd,
        "maNV": cleanMaNV, 
        "ngayBatDau": from,
        "ngayKetThuc": to,
        "luongCoBan": luong,
        "heSoLuong": heSo || 1.0
    };

    console.log(">>> Dữ liệu chuẩn bị bắn API:", payload);

    try {
        const response = await apiFetch('http://localhost:8080/api/hop-dong/them', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errText = await response.text();
            throw new Error(errText || `Lỗi HTTP: ${response.status}`);
        }

        alert("Ký hợp đồng mới thành công!");
        closeContractModal();
        
        loadContractsFromAPI(); 

    } catch (error) {
        console.error(">>> Lỗi khi gửi lệnh fetch:", error);
        alert("Thất bại: " + error.message);
    }
}

function closeContractModal() { 
    const modal = document.getElementById('contractModal');
    if (modal) modal.style.display = 'none'; 
}

// KHỞI TẠO KHI VÀO TRANG HỢP ĐỒNG
document.addEventListener("DOMContentLoaded", function() {
    const menuHopDong = document.querySelector('.menu-item:nth-child(4)'); 
    const section = document.getElementById('contract-section');
    
    if (menuHopDong) {
        menuHopDong.addEventListener('click', function(e) {
            e.preventDefault();
            
            document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
            this.classList.add('active');
            document.querySelectorAll('.content-body').forEach(s => s.style.display = 'none');
            
            if(section) {
                section.style.display = 'block';
                loadContractsFromAPI();
            }
        });
    }
});

// Bộ lọc tìm kiếm Hợp đồng nhân viên
function handleSearchContract() {
    const keyword = document.getElementById('searchContract').value.toLowerCase().trim();
    const deptId = document.getElementById('filterDeptContract').value;

    const filtered = listContracts.filter(ct => {
        const emp = listEmployees.find(e => e.maNV == ct.maNV);
        const nameStr = String(emp ? emp.hoTen : '').toLowerCase();
        const sohdStr = String(ct.sohd || '').toLowerCase();
        const empIdpb = String(emp ? emp.idpb : '');

        const matchText = keyword === '' || nameStr.includes(keyword) || sohdStr.includes(keyword);
        const matchDept = deptId === '' || empIdpb === String(deptId);
        return matchText && matchDept;
    });

    ct_Page = 1;
    renderContractTable(filtered);
}

// Hàm mở modal ký hợp đồng mới, đồng thời điền dropdown nhân viên
function openContractModal() {
    // Điền danh sách nhân viên vào dropdown
    const selectStaff = document.getElementById('ctStaff');
    if (selectStaff) {
        selectStaff.innerHTML = listEmployees
            .filter(e => e.status === 'Active' || e.daThoiViec === 0)
            .map(e => `<option value="${e.maNV}">${e.maNV} - ${e.hoTen}</option>`)
            .join('');
    }

    const modal = document.getElementById('contractModal');
    if (modal) modal.style.display = 'flex';
}

// Hàm mở modal thôi việc, điền dropdown nhân viên đang làm việc (chung)
function openResignModal() {
    const selectStaff = document.getElementById('rsStaff');
    if (selectStaff) {
        selectStaff.innerHTML = listEmployees
            .filter(e => e.daThoiViec === 0)
            .map(e => `<option value="${e.maNV}">${e.maNV} - ${e.hoTen}</option>`)
            .join('');
    }

    const modal = document.getElementById('resignModal');
    if (modal) modal.style.display = 'flex';
}

function closeResignModal() {
    const modal = document.getElementById('resignModal');
    if (modal) modal.style.display = 'none';
}

// Hàm mở modal thôi việc, đồng thời điền dropdown nhân viên đang làm việc (riêng)
function openResignFromContract(maNV) {
    const selectStaff = document.getElementById('rsStaff');
    if (selectStaff) {
        // Điền danh sách nhân viên đang làm
        selectStaff.innerHTML = listEmployees
            .filter(e => e.daThoiViec !== 1)
            .map(e => `<option value="${e.maNV}" ${e.maNV == maNV ? 'selected' : ''}>${e.maNV} - ${e.hoTen}</option>`)
            .join('');
    }

    const modal = document.getElementById('resignModal');
    if (modal) modal.style.display = 'flex';
}















// =============================================================
// API BACKEND ĐƯỢC GỌI TRONG FILE NÀY
// =============================================================
// 1. loadContractsFromAPI() - Tải danh sách hợp đồng
//    - GET /api/hop-dong/danh-sach    → HopDongController
//    - GET /api/nhan-vien/danh-sach   → NhanVienController
//
// 2. saveContract() - Ký hợp đồng mới
//    - POST /api/hop-dong/them        → HopDongController
// =============================================================