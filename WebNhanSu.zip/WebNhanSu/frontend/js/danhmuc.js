/* eslint-disable no-unused-vars */

// =============================================================
// 1. KHỞI CHẠY
// =============================================================
document.addEventListener("DOMContentLoaded", function() {
    const menuSetting = document.getElementById('menu-caidat') || document.getElementById('menu-admin'); // nút bấm trên sidebar
    const sectionAdmin = document.getElementById('admin-section'); // phần nội dung hiển thị khi bấm vào "Cài đặt hệ thống"

    if (menuSetting) {
        menuSetting.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
            this.classList.add('active');
            document.querySelectorAll('.content-body').forEach(el => el.style.display = 'none');
            if (sectionAdmin) {
                sectionAdmin.style.display = 'block';
                renderSettings();
            }
        });
    }
});

async function renderSettings() {
    await renderDeptList();
    await renderRoleList();
    renderPermissionList();
}

// =============================================================
// 2. PHÒNG BAN
// =============================================================
async function renderDeptList() {
    const container = document.getElementById('deptList');
    if (!container) return;
    container.innerHTML = '<div style="padding:10px; color:#6b7280;">Đang tải...</div>';

    const [pbRes, nvRes] = await Promise.all([
        apiFetch('http://localhost:8080/api/phong-ban/danh-sach'),
        apiFetch('http://localhost:8080/api/nhan-vien/danh-sach')
    ]);
    const depts = await pbRes.json();
    const employees = await nvRes.json();

    container.innerHTML = '';
    depts.forEach(dept => {
        const count = employees.filter(e => e.idpb === dept.idpb).length;
        const manager = employees.find(e => e.idpb === dept.idpb &&
            (danhSachChucVu.find(cv => cv.idcv === e.idcv)?.tenCV?.includes('Trưởng') ||
             danhSachChucVu.find(cv => cv.idcv === e.idcv)?.tenCV?.includes('Giám đốc')));
        const managerName = manager ? manager.hoTen : 'Chưa bổ nhiệm';

        const div = document.createElement('div');
        div.className = 'list-item';
        div.style.cursor = 'pointer';
        div.onclick = () => viewDeptDetail(dept.idpb, dept.tenPB);
        div.innerHTML = `
            <div class="item-icon-circle"><i class="fa-regular fa-building"></i></div>
            <div class="item-content">
                <h5>${dept.tenPB}</h5>
                <span class="sub-text"><i class="fa-solid fa-user-tie"></i> TP: ${managerName}</span>
            </div>
            <span class="badge-count" style="margin-right: 10px;">${count} nhân viên</span>
            <i class="fa-solid fa-trash-can" onclick="event.stopPropagation(); deleteDept(${dept.idpb}, '${dept.tenPB}')"
               style="color:#ef4444; cursor:pointer;" title="Xóa"></i>
        `;
        container.appendChild(div);
    });
}

//a
async function addDepartment() {
    const name = prompt("Nhập tên phòng ban mới:");
    if (!name) return;

    const res = await apiFetch('http://localhost:8080/api/phong-ban/them', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tenPB: name })
    });

    if (res.ok) {
        alert("Thêm phòng ban thành công!");
        await renderDeptList();
        await loadAllDataFromAPI(); // Cập nhật lại dropdown toàn hệ thống
    } else {
        const err = await res.text();
        alert("Lỗi: " + err);
    }
}

async function deleteDept(id, tenPB) {
    // Kiểm tra còn nhân viên không
    const nvRes = await apiFetch('http://localhost:8080/api/nhan-vien/danh-sach');
    const employees = await nvRes.json();
    const hasEmployee = employees.some(e => e.idpb === id && e.daThoiViec === 0);

    if (hasEmployee) {
        alert(`Không thể xóa phòng "${tenPB}" vì đang có nhân viên làm việc!`);
        return;
    }

    if (confirm(`Xóa phòng ban "${tenPB}"?`)) {
        const res = await apiFetch(`http://localhost:8080/api/phong-ban/xoa/${id}`, { method: 'DELETE' });
        if (res.ok) {
            alert("Đã xóa!");
            await renderDeptList();
            await loadAllDataFromAPI();
        }
    }
}

// =============================================================
// 3. CHỨC VỤ
// =============================================================
async function renderRoleList() {
    const container = document.getElementById('posList');
    if (!container) return;
    container.innerHTML = '<div style="padding:10px; color:#6b7280;">Đang tải...</div>';

    const res = await apiFetch('http://localhost:8080/api/chuc-vu/danh-sach');
    const roles = await res.json();

    const capMap = { 1: { label: 'Cấp 1', cls: 'lvl-1' }, 2: { label: 'Cấp 2', cls: 'lvl-2' },
                     3: { label: 'Cấp 3', cls: 'lvl-3' }, 4: { label: 'Cấp 4', cls: 'lvl-4' } };

    container.innerHTML = '';
    roles.forEach((role, idx) => {
        const cap = capMap[idx + 1] || { label: 'Khác', cls: 'lvl-3' };
        const div = document.createElement('div');
        div.className = 'list-item';
        div.style.cursor = 'pointer'; 
        div.onclick = () => viewPositionDetail(role.idcv, role.tenCV);
        div.innerHTML = `
            <div class="item-content">
                <h5>${role.tenCV}</h5>
                <span class="sub-text">Phụ cấp: <b style="color:#ea580c">
                    ${Number(role.phuCap || 0).toLocaleString()} ₫
                </b></span>
            </div>
            <div style="display:flex; align-items:center; gap:15px;">
                <span class="badge-level ${cap.cls}">${cap.label}</span>
                <i class="fa-solid fa-pen-to-square"
                   onclick="event.stopPropagation(); editRoleAllowance(${role.idcv}, '${role.tenCV}', ${role.phuCap || 0})"
                   style="color:#2563eb; cursor:pointer;" title="Sửa phụ cấp"></i>
                <i class="fa-solid fa-trash-can"
                   onclick="event.stopPropagation(); deleteRole(${role.idcv}, '${role.tenCV}')"
                   style="color:#ef4444; cursor:pointer;" title="Xóa"></i>
            </div>
        `;
        container.appendChild(div);
    });
}

async function addPosition() {
    const name = prompt("Nhập tên chức vụ mới:");
    if (!name) return;

    const allowance = prompt("Nhập phụ cấp (VNĐ):", "0");
    if (allowance === null) return;

    const res = await apiFetch('http://localhost:8080/api/chuc-vu/them', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tenCV: name, phuCap: Number(allowance) })
    });

    if (res.ok) {
        alert("Thêm chức vụ thành công!");
        await renderRoleList();
        await loadAllDataFromAPI();
    } else {
        const err = await res.text();
        alert("Lỗi: " + err);
    }
}

async function editRoleAllowance(id, tenCV, phuCapHienTai) {
    const newAllowance = prompt(`Nhập phụ cấp mới cho "${tenCV}":`, phuCapHienTai);
    if (newAllowance === null) return;

    const amount = Number(newAllowance);
    if (isNaN(amount) || amount < 0) { alert("Số tiền không hợp lệ!"); return; }

    const res = await apiFetch(`http://localhost:8080/api/chuc-vu/sua/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phuCap: amount })
    });

    if (res.ok) {
        alert(`Đã cập nhật phụ cấp: ${amount.toLocaleString()} ₫`);
        await renderRoleList();
        await loadAllDataFromAPI();
    }
}

async function deleteRole(id, tenCV) {
    const nvRes = await apiFetch('http://localhost:8080/api/nhan-vien/danh-sach');
    const employees = await nvRes.json();
    const hasEmployee = employees.some(e => e.idcv === id && e.daThoiViec === 0);

    if (hasEmployee) {
        alert(`Không thể xóa "${tenCV}" vì đang có nhân viên nắm giữ!`);
        return;
    }

    if (confirm(`Xóa chức vụ "${tenCV}"?`)) {
        const res = await apiFetch(`http://localhost:8080/api/chuc-vu/xoa/${id}`, { method: 'DELETE' });
        if (res.ok) {
            alert("Đã xóa!");
            await renderRoleList();
            await loadAllDataFromAPI();
        }
    }
}

// =============================================================
// 4. PHÂN QUYỀN 
// =============================================================
async function renderPermissionList() {
    const tbody = document.getElementById('permList');
    if (!tbody) return;
    tbody.innerHTML = '';

    const res = await apiFetch('http://localhost:8080/api/tai-khoan/danh-sach');
    const accounts = await res.json();

    defaultPerms.forEach(perm => {
        const count = accounts.filter(acc => acc.role === perm.code).length;
        const tr = document.createElement('tr');
        tr.style.borderBottom = '1px solid #f3f4f6';
        tr.innerHTML = `
            <td style="padding:12px;">
                <div style="display:flex; align-items:center; gap:10px">
                    <i class="fa-solid fa-lock" style="color:#6b7280"></i>
                    <span style="font-weight:600; font-size:14px; color:#374151;">${perm.name}</span>
                </div>
            </td>
            <td style="padding:12px; color:#6b7280; font-size:14px;">${count} tài khoản</td>
            <td style="padding:12px;">
                <span style="background:${perm.color}; color:${perm.text}; padding:2px 8px; border-radius:12px; font-size:12px; font-weight:500;">
                    ${perm.desc}
                </span>
            </td>
            <td style="padding:12px; text-align:right;">
                <a href="#" onclick="viewPermAccounts('${perm.code}', '${perm.name}')"
                   style="color:#2563eb; text-decoration:none; font-size:14px;">Cấu hình</a>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function addPermissionGroup() {
    alert("Chức năng này cần được cấu hình từ backend!");
}

// Xem tài khoản theo nhóm quyền
async function viewPermAccounts(permCode, permName) {
    const res = await apiFetch('http://localhost:8080/api/tai-khoan/danh-sach');
    const accounts = await res.json();

    const members = accounts
        .filter(acc => acc.role === permCode)
        .map(acc => ({
            id: acc.maNV ? 'NV' + acc.maNV : '---',
            name: acc.displayName,
            role: `User: <b>${acc.username}</b>`
        }));

    showDetailModal(`Nhóm quyền: ${permName}`, members);
}

// =============================================================
// 5. MODAL XEM CHI TIẾT
// =============================================================
async function viewDeptDetail(idpb, tenPB) {
    const res = await apiFetch('http://localhost:8080/api/nhan-vien/danh-sach');
    const employees = await res.json();
    const members = employees
        .filter(e => e.idpb === idpb)
        .map(e => ({
            id: 'NV' + e.maNV,
            name: e.hoTen,
            role: danhSachChucVu.find(cv => cv.idcv === e.idcv)?.tenCV || '---'
        }));
    showDetailModal(`Phòng: ${tenPB}`, members);
}

async function viewPositionDetail(idcv, tenCV) {
    const res = await apiFetch('http://localhost:8080/api/nhan-vien/danh-sach');
    const employees = await res.json();
    const members = employees
        .filter(e => e.idcv === idcv)
        .map(e => ({
            id: 'NV' + e.maNV,
            name: e.hoTen,
            role: danhSachPhongBan.find(pb => pb.idpb === e.idpb)?.tenPB || '---'
        }));
    showDetailModal(`Chức vụ: ${tenCV}`, members);
}

function showDetailModal(titleText, members) {
    const modal = document.getElementById('deptDetailModal');
    const title = document.getElementById('deptDetailTitle');
    const tbody = document.getElementById('deptDetailBody');
    const noData = document.getElementById('noDataMsg');

    if (title) title.innerText = `${titleText} (${members.length})`;
    if (tbody) {
        tbody.innerHTML = '';
        if (members.length === 0) {
            if (noData) noData.style.display = 'block';
        } else {
            if (noData) noData.style.display = 'none';
            members.forEach(m => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td style="padding:10px; border-bottom:1px solid #eee;"><b>${m.id}</b></td>
                    <td style="padding:10px; border-bottom:1px solid #eee;">
                        <div style="display:flex; align-items:center; gap:10px;">
                            <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(m.name)}&background=random&size=30" style="border-radius:50%;">
                            ${m.name}
                        </div>
                    </td>
                    <td style="padding:10px; border-bottom:1px solid #eee;">${m.role}</td>
                `;
                tbody.appendChild(tr);
            });
        }
    }
    if (modal) modal.style.display = 'flex';
}

function closeDeptModal() {
    const modal = document.getElementById('deptDetailModal');
    if (modal) modal.style.display = 'none';
}

// Dữ liệu mặc định phân quyền
const defaultPerms = [
    { code: 'ADMIN', name: 'Super Admin', desc: 'Toàn quyền hệ thống', color: '#dcfce7', text: '#166534' },
    { code: 'HR', name: 'Quản lý Nhân sự', desc: 'Quản lý NV, Hợp đồng', color: '#e0f2fe', text: '#075985' },
    { code: 'ACCOUNTANT', name: 'Kế toán', desc: 'Bảng lương, Chấm công', color: '#f0fdf4', text: '#15803d' }
];






















// =============================================================
// API BACKEND ĐƯỢC GỌI TRONG FILE NÀY
// =============================================================
// 1. renderDeptList() - Hiển thị danh sách phòng ban
//    - GET /api/phong-ban/danh-sach      → PhongBanController
//    - GET /api/nhan-vien/danh-sach      → NhanVienController
//
// 2. addDepartment() - Thêm phòng ban
//    - POST /api/phong-ban/them          → PhongBanController
//
// 3. deleteDept() - Xóa phòng ban
//    - GET /api/nhan-vien/danh-sach      → NhanVienController (kiểm tra còn NV không)
//    - DELETE /api/phong-ban/xoa/{id}    → PhongBanController
//
// 4. renderRoleList() - Hiển thị danh sách chức vụ
//    - GET /api/chuc-vu/danh-sach        → ChucVuController
//
// 5. addPosition() - Thêm chức vụ
//    - POST /api/chuc-vu/them            → ChucVuController
//
// 6. editRoleAllowance() - Sửa phụ cấp chức vụ
//    - PUT /api/chuc-vu/sua/{id}         → ChucVuController
//
// 7. deleteRole() - Xóa chức vụ
//    - GET /api/nhan-vien/danh-sach      → NhanVienController (kiểm tra còn NV không)
//    - DELETE /api/chuc-vu/xoa/{id}      → ChucVuController
//
// 8. renderPermissionList() - Hiển thị phân quyền
//    - GET /api/tai-khoan/danh-sach      → TaiKhoanController
//
// 9. viewPermAccounts() - Xem tài khoản theo nhóm quyền
//    - GET /api/tai-khoan/danh-sach      → TaiKhoanController
//
// 10. viewDeptDetail() & viewPositionDetail() - Xem chi tiết
//    - GET /api/nhan-vien/danh-sach      → NhanVienController
// =============================================================