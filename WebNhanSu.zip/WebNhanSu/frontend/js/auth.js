//a-tu dong gan token
function authHeaders(extra = {}) {
    return {
        'Authorization': 'Bearer ' + localStorage.getItem('token'),
        'Content-Type': 'application/json',
        ...extra
    };
}

//Wrapper fetch tự động gắn token, tự động redirect về login nếu 401
async function apiFetch(url, options = {}) {
    const token = localStorage.getItem('token');
    const res = await fetch(url, {
        ...options,
        headers: {
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json',
            ...(options.headers || {})
        }
    });

    if (res.status === 401) {
        alert('Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại!');
        localStorage.removeItem('token');
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
        return null;
    }

    if (res.status === 403) {
        alert('Bạn không có quyền thực hiện thao tác này!');
        return null;
    }

    return res;
}
