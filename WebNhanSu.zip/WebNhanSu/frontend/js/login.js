// 1. KIỂM TRA GHI NHỚ ĐĂNG NHẬP KHI TẢI TRANG
document.addEventListener("DOMContentLoaded", function() {
    const remembered = localStorage.getItem('rememberedUser');
    if (remembered) {
        const { username, password } = JSON.parse(remembered);
        document.getElementById('username').value = username;
        document.getElementById('password').value = password;
        document.getElementById('rememberMe').checked = true;
    }
});

// 2. HÀM XỬ LÝ KHI BẤM NÚT ĐĂNG NHẬP
async function handleLogin(event) {
    event.preventDefault();

    const usInput = document.getElementById('username').value.trim();
    const pwInput = document.getElementById('password').value.trim();

    const errorElement = document.getElementById('errorMessage');
    errorElement.innerText = "";
    errorElement.style.color = "red";

    if (!usInput && !pwInput) { errorElement.innerText = "Vui lòng nhập đầy đủ Tên đăng nhập và Mật khẩu!"; return; }
    if (!usInput) { errorElement.innerText = "Vui lòng nhập Tên đăng nhập!"; return; }
    if (!pwInput) { errorElement.innerText = "Vui lòng nhập Mật khẩu!"; return; }

    const btnLogin = document.querySelector('.btn-login');
    btnLogin.innerText = "Đang đăng nhập...";
    btnLogin.style.opacity = "0.7";

    try {
        //1
        const res = await fetch('http://localhost:8080/api/tai-khoan/dang-nhap', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: usInput, password: pwInput })
        });

        if (!res.ok) {
            const err = await res.text();
            errorElement.innerText = err;
            btnLogin.innerText = "Đăng nhập";
            btnLogin.style.opacity = "1";
            return;
        }

        // Lưu TOKEN + thông tin người dùng
        const data = await res.json();

        //4
        localStorage.setItem('token', data.token);                   // 👈 LƯU TOKEN
        localStorage.setItem('currentUser', JSON.stringify({
            id:       data.id,
            username: data.username,
            role:     data.role,
            fullname: data.displayName,
            maNV:     data.maNV
        }));

        const rememberMe = document.getElementById('rememberMe').checked;
        if (rememberMe) {
            localStorage.setItem('rememberedUser', JSON.stringify({ username: usInput, password: pwInput }));
        } else {
            localStorage.removeItem('rememberedUser');
        }

        setTimeout(() => {
            alert(`✅ Xin chào ${data.displayName}!`);
            window.location.href = 'dashboard.html';
        }, 500);

    } catch (err) {
        errorElement.innerText = "Không thể kết nối đến máy chủ!";
        btnLogin.innerText = "Đăng nhập";
        btnLogin.style.opacity = "1";
    }
}

// 3. LẮNG NGHE SỰ KIỆN
document.getElementById('loginForm').addEventListener('submit', handleLogin);

// 4. XỬ LÝ ẨN/HIỆN MẬT KHẨU
const togglePassIcon = document.querySelector('.show-pass-icon');
const passwordField = document.getElementById('password');

togglePassIcon.addEventListener('click', function() {
    const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordField.setAttribute('type', type);
    this.classList.toggle('fa-eye');
    this.classList.toggle('fa-eye-slash');
});
