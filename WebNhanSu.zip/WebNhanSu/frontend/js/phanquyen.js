/* eslint-disable no-unused-vars */

let listTaiKhoan = [];

// =============================================================
// 1. LOAD VÀ VẼ BẢNG TÀI KHOẢN
// =============================================================
async function renderUserTable() {
    const tbody = document.getElementById('userTableBody');
    if (!tbody) return;

    const res = await apiFetch('http://localhost:8080/api/tai-khoan/danh-sach');
    listTaiKhoan = await res.json();

    tbody.innerHTML = '';
    listTaiKhoan.forEach(user => {
        let badgeStyle;
        if (user.role === 'ADMIN') badgeStyle = 'background:#DEF7EC; color:#03543F;';
        else if (user.role === 'HR') badgeStyle = 'background:#E1EFFE; color:#1E429F;';
        else if (user.role === 'ACCOUNTANT') badgeStyle = 'background:#F3F4F6; color:#1F2937;';
        else badgeStyle = 'background:#FFF1F2; color:#9F1239;';

        const statusHtml = user.trangThai === 1
            ? '<span style="background:#dcfce7; color:#166534; padding:2px 8px; border-radius:10px; font-size:12px;">Hoạt động</span>'
            : '<span style="background:#fee2e2; color:#991b1b; padding:2px 8px; border-radius:10px; font-size:12px;">Đang khóa</span>';

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <div class="profile-flex">
                    <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(user.displayName)}&background=random" 
                         class="profile-avatar" style="width:32px;height:32px;">
                    <div class="profile-detail">
                        <span class="profile-name-text">${user.displayName}</span>
                    </div>
                </div>
            </td>
            <td style="font-family:monospace; color:#4B5563;">${user.username}</td>
            <td>
                <span style="padding:4px 10px; border-radius:4px; font-size:12px; font-weight:600; ${badgeStyle}">
                    ${user.role}
                </span>
            </td>
            <td>${statusHtml}</td>
            <td>
                <button class="action-icon-btn edit" title="Phân quyền" onclick="openRoleModal(${user.id})">
                    <i class="fa-solid fa-user-gear"></i>
                </button>
                <button class="action-icon-btn" title="${user.trangThai === 1 ? 'Khóa' : 'Mở khóa'}" 
                        onclick="khoaTaiKhoan(${user.id})"
                        style="color:${user.trangThai === 1 ? '#dc2626' : '#16a34a'}">
                    <i class="fa-solid fa-${user.trangThai === 1 ? 'lock' : 'lock-open'}"></i>
                </button>
                <button class="action-icon-btn" title="Reset mật khẩu" onclick="resetMatKhau(${user.id})">
                    <i class="fa-solid fa-key"></i>
                </button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

// =============================================================
// 2. PHÂN QUYỀN
// =============================================================
function openRoleModal(id) {
    const user = listTaiKhoan.find(u => u.id === id);
    if (!user) return;

    document.getElementById('editUserId').value = user.id;
    document.getElementById('displayUsername').value = user.username;
    document.getElementById('displayFullname').value = user.displayName;
    document.getElementById('selectRole').value = user.role;

    const modal = document.getElementById('roleModal');
    if (modal) modal.style.display = 'flex';
}

function closeModal() {
    const modal = document.getElementById('roleModal');
    if (modal) modal.style.display = 'none';
}

async function saveRole() {
    const id = parseInt(document.getElementById('editUserId').value);
    const newRole = document.getElementById('selectRole').value;

    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    const user = listTaiKhoan.find(u => u.id === id);
    if (currentUser && user && user.username === currentUser.username && newRole !== 'ADMIN') {
        alert("Không thể tự gỡ quyền Admin của chính mình!");
        return;
    }

    const res = await apiFetch(`http://localhost:8080/api/tai-khoan/doi-quyen/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole })
    });

    if (res.ok) {
        alert("Đã cập nhật quyền thành công!");
        closeModal();
        renderUserTable();
    }
}

// =============================================================
// 3. KHÓA / MỞ KHÓA
// =============================================================
async function khoaTaiKhoan(id) {
    const user = listTaiKhoan.find(u => u.id === id);
    const action = user.trangThai === 1 ? 'khóa' : 'mở khóa';
    if (!confirm(`Xác nhận ${action} tài khoản "${user.username}"?`)) return;

    const res = await apiFetch(`http://localhost:8080/api/tai-khoan/khoa/${id}`, { method: 'PUT' });
    if (res.ok) {
        alert(`Đã ${action} tài khoản!`);
        renderUserTable();
    }
}

// =============================================================
// 4. RESET MẬT KHẨU
// =============================================================
async function resetMatKhau(id) {
    const user = listTaiKhoan.find(u => u.id === id);
    if (!confirm(`Reset mật khẩu của "${user.username}" về 123456?`)) return;

    const res = await apiFetch(`http://localhost:8080/api/tai-khoan/reset-mat-khau/${id}`, { method: 'PUT' });
    if (res.ok) alert("Đã reset mật khẩu về 123456!");
}

// =============================================================
// 5. KHỞI CHẠY
// =============================================================
document.addEventListener("DOMContentLoaded", function() {
    const menuAdmin = document.getElementById('menu-admin');
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));

    if (currentUser && currentUser.role !== 'ADMIN') {
        if (menuAdmin) menuAdmin.style.display = 'none';
        return;
    }

    const sectionAdmin = document.getElementById('admin-section');
    if (menuAdmin) {
        menuAdmin.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('.menu-item').forEach(el => el.classList.remove('active'));
            this.classList.add('active');
            document.querySelectorAll('.content-body').forEach(el => el.style.display = 'none');
            if (sectionAdmin) {
                sectionAdmin.style.display = 'block';
                renderUserTable();
            }
        });
    }
});

// bật tắt bảng quản lý tài khoản
function openUserManageModal() {
    const section = document.getElementById('userTableSection');
    if (!section) return;

    if (section.style.display === 'none' || section.style.display === '') {
        section.style.display = 'block';
        section.scrollIntoView({ behavior: 'smooth' });
        renderUserTable();
    } else {
        section.style.display = 'none';
    }
}