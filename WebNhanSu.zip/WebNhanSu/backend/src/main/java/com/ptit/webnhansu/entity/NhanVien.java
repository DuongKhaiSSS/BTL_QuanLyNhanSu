package com.ptit.webnhansu.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "tb_NHANVIEN")
public class NhanVien {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MANV")
    private Integer maNV;

    @Column(name = "HOTEN")
    private String hoTen;

    // ĐÃ SỬA: Đổi từ String sang Integer cho khớp số 1, 0 trong SQL
    @Column(name = "GIOITINH")
    private Integer gioiTinh;

    @Column(name = "NGAYSINH")
    private LocalDate ngaySinh;

    @Column(name = "DIENTHOAI")
    private String dienThoai;

    @Column(name = "CCCD")
    private String cccd;

    @Column(name = "DIACHI")
    private String diaChi;

    @Column(name = "HINHANH")
    private String hinhAnh;

    @Column(name = "IDPB")
    private Integer idpb;

    @Column(name = "IDBP")
    private Integer idbp;

    @Column(name = "IDCV")
    private Integer idcv;

    @Column(name = "IDTD")
    private Integer idtd;

    @Column(name = "IDTG")
    private Integer idtg;

    // ĐÃ SỬA: Đổi từ Boolean sang Integer cho chắc cốp với SQL
    @Column(name = "DATHOIVIEC")
    private Integer daThoiViec;

    // --- GETTER VÀ SETTER ---

    public Integer getMaNV() {
        return maNV;
    }

    public void setMaNV(Integer maNV) {
        this.maNV = maNV;
    }

    public String getHoTen() {
        return hoTen;
    }

    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    public Integer getGioiTinh() {
        return gioiTinh;
    } // Đã sửa

    public void setGioiTinh(Integer gioiTinh) {
        this.gioiTinh = gioiTinh;
    } // Đã sửa

    public LocalDate getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(LocalDate ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getDienThoai() {
        return dienThoai;
    }

    public void setDienThoai(String dienThoai) {
        this.dienThoai = dienThoai;
    }

    public String getCccd() {
        return cccd;
    }

    public void setCccd(String cccd) {
        this.cccd = cccd;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getHinhAnh() {
        return hinhAnh;
    }

    public void setHinhAnh(String hinhAnh) {
        this.hinhAnh = hinhAnh;
    }

    public Integer getIdpb() {
        return idpb;
    }

    public void setIdpb(Integer idpb) {
        this.idpb = idpb;
    }

    public Integer getIdbp() {
        return idbp;
    }

    public void setIdbp(Integer idbp) {
        this.idbp = idbp;
    }

    public Integer getIdcv() {
        return idcv;
    }

    public void setIdcv(Integer idcv) {
        this.idcv = idcv;
    }

    public Integer getIdtd() {
        return idtd;
    }

    public void setIdtd(Integer idtd) {
        this.idtd = idtd;
    }

    public Integer getIdtg() {
        return idtg;
    }

    public void setIdtg(Integer idtg) {
        this.idtg = idtg;
    }

    public Integer getDaThoiViec() {
        return daThoiViec;
    } // Đã sửa

    public void setDaThoiViec(Integer daThoiViec) {
        this.daThoiViec = daThoiViec;
    } // Đã sửa
}