package com.ptit.webnhansu.controller;

import com.ptit.webnhansu.entity.BangCong;
import com.ptit.webnhansu.repository.BangCongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bang-cong")
public class BangCongController {

    @Autowired
    private BangCongRepository bangCongRepo;

    // Lấy bảng công theo tháng
    @GetMapping("/lay-theo-thang")
    public List<BangCong> getByMonth(@RequestParam String period) {
        String[] parts = period.split("-");
        Integer nam = Integer.parseInt(parts[0]);
        Integer thang = Integer.parseInt(parts[1]);
        return bangCongRepo.findByNamAndThang(nam, thang);
    }

    // Lưu hàng loạt dữ liệu chấm công
    @PostMapping("/luu-danh-sach")
    public void saveAll(@RequestBody List<BangCong> list) {
        if (list != null) {
            for (BangCong bc : list) {
                bc.setNhanVien(null);

                // 2. Chống lỗi Foreign Key: Nếu maNV là 0 hoặc null, gán mặc định cho NV số 1
                if (bc.getMaNV() == null || bc.getMaNV() == 0) {
                    bc.setMaNV(1);
                }

                // 3. Logic Upsert: Tự động chọn giữa INSERT hoặc UPDATE
                var recordCu = bangCongRepo.findByMaNVAndNamAndThang(
                        bc.getMaNV(), bc.getNam(), bc.getThang());

                if (recordCu.isPresent()) {
                    bc.setMabc(recordCu.get().getMabc()); // Có rồi thì UPDATE
                } else {
                    bc.setMabc(null); // Chưa có thì INSERT mới
                }
            }
        }
        bangCongRepo.saveAll(list);
    }
}