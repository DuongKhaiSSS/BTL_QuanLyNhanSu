package com.ptit.webnhansu.controller;

import com.ptit.webnhansu.entity.PhongBan;
import com.ptit.webnhansu.repository.PhongBanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException; // Cần thêm import này
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/phong-ban")
public class PhongBanController {

    @Autowired
    private PhongBanRepository phongBanRepository;

    @GetMapping("/danh-sach")
    public List<PhongBan> layDanhSach() {
        return phongBanRepository.findAll();
    }

    // b
    @PostMapping("/them")
    public ResponseEntity<?> them(@RequestBody PhongBan phongBan) {
        if (phongBan.getTenPB() == null || phongBan.getTenPB().isBlank()) {
            return ResponseEntity.badRequest().body("Tên phòng ban không được trống!");
        }
        boolean trung = phongBanRepository.findAll()
                .stream().anyMatch(p -> p.getTenPB().equalsIgnoreCase(phongBan.getTenPB()));
        if (trung)
            return ResponseEntity.badRequest().body("Tên phòng ban đã tồn tại!");
        return ResponseEntity.ok(phongBanRepository.save(phongBan));
    }

    @DeleteMapping("/xoa/{id}")
    public ResponseEntity<?> xoa(@PathVariable Integer id) {
        if (!phongBanRepository.existsById(id)) {
            return ResponseEntity.badRequest().body("Không tìm thấy phòng ban!");
        }

        try {
            phongBanRepository.deleteById(id);
            return ResponseEntity.ok("Đã xóa!");
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.badRequest().body("Không thể xóa! Phòng ban này đang có nhân viên.");
        }
    }
}