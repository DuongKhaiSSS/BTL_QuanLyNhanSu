package com.ptit.webnhansu.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "tb_PHONGBAN")
public class PhongBan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IDPB")
    private Integer idpb;

    @Column(name = "TENPB")
    private String tenPB;

    public Integer getIdpb() { return idpb; }
    public void setIdpb(Integer idpb) { this.idpb = idpb; }
    public String getTenPB() { return tenPB; }
    public void setTenPB(String tenPB) { this.tenPB = tenPB; }
}