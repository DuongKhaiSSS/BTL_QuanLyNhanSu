package com.ptit.webnhansu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebnhansuApplication {
	public static void main(String[] args) {
		SpringApplication.run(WebnhansuApplication.class, args);
	}

}
