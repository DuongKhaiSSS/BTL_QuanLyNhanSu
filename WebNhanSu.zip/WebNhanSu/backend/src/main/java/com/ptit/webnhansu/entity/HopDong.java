package com.ptit.webnhansu.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonAlias;

@Entity
@Table(name = "tb_HOPDONG")
public class HopDong {
    @Id
    @Column(name = "SOHD")
    private String sohd;

    @Column(name = "NGAYBATDAU")
    private LocalDate ngayBatDau;
    @Column(name = "NGAYKETTHUC")
    private LocalDate ngayKetThuc;
    @Column(name = "NGAYKY")
    private LocalDate ngayKy;
    @Column(name = "LANKY")
    private Integer lanKy;
    @Column(name = "THOIHAN")
    private String thoiHan;
    @Column(name = "HESOLUONG")
    private Double heSoLuong;
    @Column(name = "LUONGCOBAN")
    private Double luongCoBan;

    @Column(name = "MANV")
    private Integer maNV;

    @Column(name = "TRANGTHAI")
    private Integer trangThai;

    @Column(name = "PHUCAP")
    private Double phuCap;

    // =============================================================
    // GETTER & SETTER (ĐÃ GẮN BÙA TRỰC TIẾP VÀO HÀM)
    // =============================================================

    public String getSohd() {
        return sohd;
    }

    public void setSohd(String sohd) {
        this.sohd = sohd;
    }

    public LocalDate getNgayBatDau() {
        return ngayBatDau;
    }

    public void setNgayBatDau(LocalDate ngayBatDau) {
        this.ngayBatDau = ngayBatDau;
    }

    public LocalDate getNgayKetThuc() {
        return ngayKetThuc;
    }

    public void setNgayKetThuc(LocalDate ngayKetThuc) {
        this.ngayKetThuc = ngayKetThuc;
    }

    public LocalDate getNgayKy() {
        return ngayKy;
    }

    public void setNgayKy(LocalDate ngayKy) {
        this.ngayKy = ngayKy;
    }

    public Integer getLanKy() {
        return lanKy;
    }

    public void setLanKy(Integer lanKy) {
        this.lanKy = lanKy;
    }

    public String getThoiHan() {
        return thoiHan;
    }

    public void setThoiHan(String thoiHan) {
        this.thoiHan = thoiHan;
    }

    public Double getHeSoLuong() {
        return heSoLuong;
    }

    public void setHeSoLuong(Double heSoLuong) {
        this.heSoLuong = heSoLuong;
    }

    public Double getLuongCoBan() {
        return luongCoBan;
    }

    public void setLuongCoBan(Double luongCoBan) {
        this.luongCoBan = luongCoBan;
    }

    public Double getPhuCap() {
        return phuCap;
    }

    public void setPhuCap(Double phuCap) {
        this.phuCap = phuCap;
    }

    @JsonProperty("maNV")
    @JsonAlias({ "manv", "MaNV", "MANV" })
    public Integer getMaNV() {
        return maNV;
    }

    @JsonProperty("maNV")
    @JsonAlias({ "manv", "MaNV", "MANV" })
    public void setMaNV(Integer maNV) {
        this.maNV = maNV;
    }

    public Integer getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(Integer trangThai) {
        this.trangThai = trangThai;
    }
}