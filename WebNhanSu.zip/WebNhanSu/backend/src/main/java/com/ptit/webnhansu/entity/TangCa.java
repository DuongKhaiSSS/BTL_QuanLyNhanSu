package com.ptit.webnhansu.entity;

import jakarta.persistence.*;
import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "tb_TANGCA")
public class TangCa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(hidden = true)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "NAM")
    private Integer nam;
    @Column(name = "THANG")
    private Integer thang;
    @Column(name = "NGAY")
    private Integer ngay;
    @Column(name = "SOGIO")
    private Double soGio;

    // BỔ SUNG: Hệ số lương tăng ca (VD: 1.5, 2.0, 3.0)
    @Column(name = "HESO")
    private Double heSo;

    @Column(name = "MANV")
    @Schema(example = "1")
    private Integer maNV;

    @ManyToOne
    @JoinColumn(name = "MANV", insertable = false, updatable = false)
    private NhanVien nhanVien;

    @Column(name = "IDLOAICA")
    @Schema(example = "1")
    private Integer idLoaiCa;

    @ManyToOne
    @JoinColumn(name = "IDLOAICA", insertable = false, updatable = false)
    private LoaiCa loaiCa;

    // --- GETTER & SETTER ---
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNam() {
        return nam;
    }

    public void setNam(Integer nam) {
        this.nam = nam;
    }

    public Integer getThang() {
        return thang;
    }

    public void setThang(Integer thang) {
        this.thang = thang;
    }

    public Integer getNgay() {
        return ngay;
    }

    public void setNgay(Integer ngay) {
        this.ngay = ngay;
    }

    public Double getSoGio() {
        return soGio;
    }

    public void setSoGio(Double soGio) {
        this.soGio = soGio;
    }

    public Double getHeSo() {
        return heSo;
    }

    public void setHeSo(Double heSo) {
        this.heSo = heSo;
    }

    public Integer getMaNV() {
        return maNV;
    }

    public void setMaNV(Integer maNV) {
        this.maNV = maNV;
    }

    public NhanVien getNhanVien() {
        return nhanVien;
    }

    public void setNhanVien(NhanVien nhanVien) {
        this.nhanVien = nhanVien;
    }

    public Integer getIdLoaiCa() {
        return idLoaiCa;
    }

    public void setIdLoaiCa(Integer idLoaiCa) {
        this.idLoaiCa = idLoaiCa;
    }

    public LoaiCa getLoaiCa() {
        return loaiCa;
    }

    public void setLoaiCa(LoaiCa loaiCa) {
        this.loaiCa = loaiCa;
    }
}