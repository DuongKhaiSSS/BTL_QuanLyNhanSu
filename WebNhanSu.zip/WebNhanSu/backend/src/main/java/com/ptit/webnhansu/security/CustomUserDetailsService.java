package com.ptit.webnhansu.security;

import com.ptit.webnhansu.repository.TaiKhoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private TaiKhoanRepository taiKhoanRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        var taiKhoan = taiKhoanRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Khong tim thay tai khoan: " + username));

        boolean isActive = taiKhoan.getTrangThai() != null && taiKhoan.getTrangThai() == 1;

        return new User(
                taiKhoan.getUsername(),
                taiKhoan.getPassword(),
                isActive,
                true,
                true,
                true,
                List.of(new SimpleGrantedAuthority("ROLE_" + taiKhoan.getRole())));
    }
}