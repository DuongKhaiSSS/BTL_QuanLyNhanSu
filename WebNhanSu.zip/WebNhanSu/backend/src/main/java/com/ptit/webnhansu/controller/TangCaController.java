package com.ptit.webnhansu.controller;

import com.ptit.webnhansu.entity.TangCa;
import com.ptit.webnhansu.repository.TangCaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tang-ca")
public class TangCaController {

    @Autowired
    private TangCaRepository tangCaRepo;

    @GetMapping("/danh-sach")
    public List<TangCa> getAll() {
        return tangCaRepo.findAll();
    }

    @PostMapping("/them")
    public TangCa addOvertime(@RequestBody TangCa tangCa) {
        // 1. Ép ID tăng ca về null để INSERT mới
        tangCa.setId(null);

        // 2.Chỉ để lại các ID để nó tự tìm trong DB
        tangCa.setLoaiCa(null);
        tangCa.setNhanVien(null);

        return tangCaRepo.save(tangCa);
    }

    // Xóa tăng ca
    @DeleteMapping("/xoa/{id}")
    public void delete(@PathVariable Integer id) {
        tangCaRepo.deleteById(id);
    }
}