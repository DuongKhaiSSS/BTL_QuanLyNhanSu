package com.ptit.webnhansu.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "tb_CHUCVU")
public class ChucVu {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IDCV")
    private Integer idcv;

    @Column(name = "TENCV")
    private String tenCV;

    // BỔ SUNG: Cột Phụ Cấp cho từng chức vụ
    @Column(name = "PHUCAP")
    private Double phuCap;

    public Integer getIdcv() {
        return idcv;
    }

    public void setIdcv(Integer idcv) {
        this.idcv = idcv;
    }

    public String getTenCV() {
        return tenCV;
    }

    public void setTenCV(String tenCV) {
        this.tenCV = tenCV;
    }

    public Double getPhuCap() {
        return phuCap;
    }

    public void setPhuCap(Double phuCap) {
        this.phuCap = phuCap;
    }
}