package com.ptit.webnhansu.controller;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.ptit.webnhansu.service.BangLuongService;
import com.ptit.webnhansu.entity.ChiTietBangLuong;
import com.ptit.webnhansu.repository.ChiTietBangLuongRepository;

@RestController
@RequestMapping("/api/bang-luong")
@CrossOrigin("*")
public class BangLuongController {

    @Autowired
    private BangLuongService bangLuongService;

    @Autowired
    private ChiTietBangLuongRepository chiTietLuongRepo;

    // POST /api/bang-luong/tinh-toan?month=03&year=2025
    @PostMapping("/tinh-toan")
    public ResponseEntity<?> tinhLuong(@RequestParam String month, @RequestParam String year) {
        try {
            String period = year + "-" + month;
            return ResponseEntity.ok(bangLuongService.tinhLuongThang(period));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage()); // Trả lỗi nếu có vấn đề trong quá trình tính lương
        }
    }

    // GET /api/bang-luong/chi-tiet?month=03&year=2025
    @GetMapping("/chi-tiet")
    public ResponseEntity<List<ChiTietBangLuong>> layBangLuong(
            @RequestParam String month,
            @RequestParam String year) {
        String period = year + "-" + month;
        return ResponseEntity.ok(bangLuongService.layDanhSachLuongThang(period));
    }

    // GET /api/bang-luong/theo-nam?maNV=1&nam=2025
    @GetMapping("/theo-nam")
    public ResponseEntity<List<ChiTietBangLuong>> layLuongTheoNam(
            @RequestParam Integer maNV,
            @RequestParam Integer nam) {
        List<ChiTietBangLuong> data = chiTietLuongRepo.findByMaNVAndNam(maNV, nam);
        return ResponseEntity.ok(data);
    }

    // GET /api/bang-luong/trang-thai?month=01&year=2026
    @GetMapping("/trang-thai")
    public ResponseEntity<?> getTrangThai(
            @RequestParam String month,
            @RequestParam String year) {
        boolean daDuyet = bangLuongService.isDaDuyet(
                Integer.parseInt(month),
                Integer.parseInt(year));
        return ResponseEntity.ok(Map.of("daDuyet", daDuyet));
    }

    // Duyệt bảng lương
    // POST /api/bang-luong/duyet?month=01&year=2026&nguoiDuyet=Admin
    @PostMapping("/duyet")
    public ResponseEntity<?> duyetBangLuong(
            @RequestParam String month,
            @RequestParam String year,
            @RequestParam String nguoiDuyet) {
        try {
            bangLuongService.duyetBangLuong(
                    Integer.parseInt(month),
                    Integer.parseInt(year),
                    nguoiDuyet);
            return ResponseEntity.ok(Map.of("success", true));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}