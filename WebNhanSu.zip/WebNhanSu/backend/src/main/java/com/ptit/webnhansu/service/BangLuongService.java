package com.ptit.webnhansu.service;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ptit.webnhansu.entity.ChamCong;
import com.ptit.webnhansu.entity.ChiTietBangLuong;
import com.ptit.webnhansu.entity.ChucVu;
import com.ptit.webnhansu.entity.HopDong;
import com.ptit.webnhansu.entity.NhanVien;
import com.ptit.webnhansu.entity.TangCa;
import com.ptit.webnhansu.repository.ChamCongRepository;
import com.ptit.webnhansu.repository.ChiTietBangLuongRepository;
import com.ptit.webnhansu.repository.ChucVuRepository;
import com.ptit.webnhansu.repository.HopDongRepository;
import com.ptit.webnhansu.repository.NhanVienRepository;
import com.ptit.webnhansu.repository.TangCaRepository;

@Service
public class BangLuongService {

    @Autowired
    private ChamCongRepository chamCongRepo;
    @Autowired
    private HopDongRepository hopDongRepo;
    @Autowired
    private TangCaRepository tangCaRepo;
    @Autowired
    private ChiTietBangLuongRepository chiTietLuongRepo;
    @Autowired
    private NhanVienRepository nhanVienRepo;
    @Autowired
    private ChucVuRepository chucVuRepo;

    @Transactional
    public List<ChiTietBangLuong> tinhLuongThang(String period) throws Exception {
        String[] parts = period.split("-");
        Integer nam = Integer.parseInt(parts[0]);
        Integer thang = Integer.parseInt(parts[1]);

        // Kiểm tra xem đã duyệt bảng lương tháng/năm này chưa
        if (isDaDuyet(thang, nam)) {
            throw new Exception("Bảng lương tháng " + thang + "/" + nam + " đã được DUYỆT! Không thể tính lại.");
        }

        List<ChamCong> dsCong = chamCongRepo.findByNamAndThang(nam, thang);
        if (dsCong.isEmpty())
            throw new Exception("Chua co bang cong thang " + period);

        chiTietLuongRepo.deleteByNamAndThang(nam, thang);

        List<ChiTietBangLuong> ketQua = new ArrayList<>();

        for (ChamCong cc : dsCong) {
            ChiTietBangLuong luong = new ChiTietBangLuong();
            luong.setMaNV(cc.getMaNV());
            luong.setNam(nam);
            luong.setThang(thang);
            luong.setNgayTinh(LocalDateTime.now());

            // A. LUONG CO BAN tu Hop dong (lay hop dong moi nhat con hieu luc)
            List<HopDong> dsHD = hopDongRepo.findByMaNV(cc.getMaNV());
            HopDong hdHieuLuc = dsHD.stream()
                    .filter(h -> h.getTrangThai() != null && h.getTrangThai() == 1)
                    .findFirst()
                    .orElse(dsHD.isEmpty() ? null : dsHD.get(0));
            double mucLuong = hdHieuLuc != null ? hdHieuLuc.getLuongCoBan() : 0;
            luong.setBaseSalary(mucLuong);

            // B. NGAY CONG THUC TE
            double ngayCong = (cc.getNgayCongThucTe() != null) ? cc.getNgayCongThucTe() : 0;
            luong.setWorkDays(ngayCong);
            double luongTheoNgayCong = (mucLuong / 26.0) * ngayCong;

            // C. TANG CA
            List<TangCa> dsTC = tangCaRepo.findByMaNVAndNamAndThang(cc.getMaNV(), nam, thang);
            double tienTC = 0;
            for (TangCa tc : dsTC) {
                double heSo = (tc.getHeSo() != null) ? tc.getHeSo() : 1.5;
                double soGio = (tc.getSoGio() != null) ? tc.getSoGio() : 0;
                tienTC += (mucLuong / 26.0 / 8.0) * soGio * heSo;
            }
            luong.setOvertimeMoney(tienTC);

            // D. PHU CAP = Phu cap tu Hop dong + Phu cap Chuc vu
            double phuCapHD = (hdHieuLuc != null && hdHieuLuc.getPhuCap() != null)
                    ? hdHieuLuc.getPhuCap()
                    : 0;

            double phuCapCV = 0;
            NhanVien nv = nhanVienRepo.findById(cc.getMaNV()).orElse(null);
            if (nv != null && nv.getIdcv() != null) {
                ChucVu cv = chucVuRepo.findById(nv.getIdcv()).orElse(null);
                if (cv != null && cv.getPhuCap() != null) {
                    phuCapCV = cv.getPhuCap();
                }
            }

            double tongPhuCap = phuCapHD + phuCapCV;
            luong.setAllowance(tongPhuCap); // Lưu tổng phụ cấp

            // E. KHAU TRU
            double baoHiem = mucLuong * 0.105;
            double thuNhapTinhThue = luongTheoNgayCong + tienTC + tongPhuCap - baoHiem - 11_000_000;
            double thueTNCN = 0;
            if (thuNhapTinhThue > 0) {
                if (thuNhapTinhThue <= 5_000_000) {
                    thueTNCN = thuNhapTinhThue * 0.05;
                } else if (thuNhapTinhThue <= 10_000_000) {
                    thueTNCN = 250_000 + (thuNhapTinhThue - 5_000_000) * 0.10;
                } else if (thuNhapTinhThue <= 18_000_000) {
                    thueTNCN = 750_000 + (thuNhapTinhThue - 10_000_000) * 0.15;
                } else if (thuNhapTinhThue <= 32_000_000) {
                    thueTNCN = 1_950_000 + (thuNhapTinhThue - 18_000_000) * 0.20;
                } else {
                    thueTNCN = 4_750_000 + (thuNhapTinhThue - 32_000_000) * 0.25;
                }
            }

            double tongKhauTru = (double) Math.round(baoHiem + thueTNCN);
            luong.setDeduction(tongKhauTru);

            // F. THUC LANH = Luong ngay cong + Tang ca + Phu cap - Khau tru
            double thucLanh = luongTheoNgayCong + tienTC + tongPhuCap - tongKhauTru;
            luong.setTotal(Math.max((double) Math.round(thucLanh), 0.0));

            ketQua.add(luong);
        }

        return chiTietLuongRepo.saveAll(ketQua);
    }

    public List<ChiTietBangLuong> layDanhSachLuongThang(String period) {
        String[] parts = period.split("-");
        Integer nam = Integer.parseInt(parts[0]);
        Integer thang = Integer.parseInt(parts[1]);
        return chiTietLuongRepo.findByNamAndThang(nam, thang);
    }

    // mới
    public boolean isDaDuyet(Integer thang, Integer nam) {
        return chiTietLuongRepo.existsByThangAndNamAndTrangThai(thang, nam, "DA_DUYET");
    }

    // Duyệt bảng lương — cập nhật trang_thai, nguoi_duyet, ngay_duyet
    @Transactional
    public void duyetBangLuong(Integer thang, Integer nam, String nguoiDuyet) {
        List<ChiTietBangLuong> list = chiTietLuongRepo.findByThangAndNam(thang, nam);
        if (list == null || list.isEmpty()) {
            throw new RuntimeException("Không có dữ liệu lương tháng " + thang + "/" + nam + " để duyệt!");
        }
        list.forEach(bl -> {
            bl.setTrangThai("DA_DUYET");
            bl.setNguoiDuyet(nguoiDuyet);
            bl.setNgayDuyet(LocalDateTime.now());
        });
        chiTietLuongRepo.saveAll(list);
    }

}

// find/exists → đọc dữ liệu
// save/saveAll new object → tạo mới
// save/saveAll find existing → cập nhật