package com.ptit.webnhansu.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_TRINHDO")
public class TrinhDo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IDTD")
    private Integer idtd;

    @Column(name = "TENTD")
    private String tentd;

    // Getter & Setter
    public Integer getIdtd() { return idtd; }
    public void setIdtd(Integer idtd) { this.idtd = idtd; }

    public String getTentd() { return tentd; }
    public void setTentd(String tentd) { this.tentd = tentd; }
}