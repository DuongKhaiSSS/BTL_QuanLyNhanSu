package com.ptit.webnhansu.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "tb_THOIVIEC")
public class ThoiViec {
    @Id 
    @Column(name = "SOQD") private String soqd; 
    @Column(name = "MANV") private Integer maNV;
    @Column(name = "NGAYNOPDON") private LocalDate ngayNopDon;
    @Column(name = "NGAYNGHI") private LocalDate ngayNghi;
    @Column(name = "LYDO") private String lyDo;

    // Getter & Setter
    public String getSoqd() { return soqd; }
    public void setSoqd(String soqd) { this.soqd = soqd; }
    public Integer getMaNV() { return maNV; }
    public void setMaNV(Integer maNV) { this.maNV = maNV; }
    public LocalDate getNgayNopDon() { return ngayNopDon; }
    public void setNgayNopDon(LocalDate ngayNopDon) { this.ngayNopDon = ngayNopDon; }
    public LocalDate getNgayNghi() { return ngayNghi; }
    public void setNgayNghi(LocalDate ngayNghi) { this.ngayNghi = ngayNghi; }
    public String getLyDo() { return lyDo; }
    public void setLyDo(String lyDo) { this.lyDo = lyDo; }
}