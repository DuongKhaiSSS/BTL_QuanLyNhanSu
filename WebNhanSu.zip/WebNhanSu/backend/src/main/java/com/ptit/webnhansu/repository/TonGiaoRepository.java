package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.TonGiao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TonGiaoRepository extends JpaRepository<TonGiao, Integer> {
}