package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.NhanVien;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface NhanVienRepository extends JpaRepository<NhanVien, Integer> {

        // Thống kê số lượng theo tên phòng ban
        @Query(value = "SELECT pb.TENPB, COUNT(nv.MANV) FROM tb_NHANVIEN nv " +
                        "LEFT JOIN tb_PHONGBAN pb ON nv.IDPB = pb.IDPB " +
                        "GROUP BY pb.TENPB", nativeQuery = true)
        List<Object[]> countByPhongBan();

        // Thống kê số lượng theo tên chức vụ
        @Query(value = "SELECT cv.TENCV, COUNT(nv.MANV) FROM tb_NHANVIEN nv " +
                        "LEFT JOIN tb_CHUCVU cv ON nv.IDCV = cv.IDCV " +
                        "GROUP BY cv.TENCV", nativeQuery = true)
        List<Object[]> countByChucVu();

        List<NhanVien> findTop6ByOrderByMaNVDesc();

        long countByDaThoiViec(Integer daThoiViec);

}