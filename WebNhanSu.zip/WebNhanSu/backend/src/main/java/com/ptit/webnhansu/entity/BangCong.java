package com.ptit.webnhansu.entity;

import jakarta.persistence.*;
import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "tb_BANGCONG")
public class BangCong {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(hidden = true) // Bảo Swagger: Đừng hiện cột này lên cho người dùng nhập
    @Column(name = "MABC")
    private Integer mabc;

    @Column(name = "NAM")
    private Integer nam;
    @Column(name = "THANG")
    private Integer thang;

    @Schema(example = "1") // Mặc định điền mã NV là 1 (Nguyễn Thanh Tùng) để tránh lỗi Foreign Key
    @Column(name = "MANV")
    private Integer maNV;

    @ManyToOne
    @JoinColumn(name = "MANV", insertable = false, updatable = false)
    private NhanVien nhanVien;

    @Column(name = "NGAYCONGTRONGTHANG")
    private Integer ngayCongTrongThang;
    @Column(name = "NGAYCONGTHUCTE")
    private Double ngayCongThucTe;
    @Column(name = "NGAYNGHIPHEP")
    private Double ngayNghiPhep;
    @Column(name = "NGAYKHONGPHEP")
    private Double ngayKhongPhep;

    // --- GETTERS & SETTERS (Đảm bảo đầy đủ để Spring mapping được dữ liệu) ---
    public Integer getMabc() {
        return mabc;
    }

    public void setMabc(Integer mabc) {
        this.mabc = mabc;
    }

    public Integer getNam() {
        return nam;
    }

    public void setNam(Integer nam) {
        this.nam = nam;
    }

    public Integer getThang() {
        return thang;
    }

    public void setThang(Integer thang) {
        this.thang = thang;
    }

    public Integer getMaNV() {
        return maNV;
    }

    public void setMaNV(Integer maNV) {
        this.maNV = maNV;
    }

    public NhanVien getNhanVien() {
        return nhanVien;
    }

    public void setNhanVien(NhanVien nhanVien) {
        this.nhanVien = nhanVien;
    }

    public Integer getNgayCongTrongThang() {
        return ngayCongTrongThang;
    }

    public void setNgayCongTrongThang(Integer ngayCongTrongThang) {
        this.ngayCongTrongThang = ngayCongTrongThang;
    }

    public Double getNgayCongThucTe() {
        return ngayCongThucTe;
    }

    public void setNgayCongThucTe(Double ngayCongThucTe) {
        this.ngayCongThucTe = ngayCongThucTe;
    }

    public Double getNgayNghiPhep() {
        return ngayNghiPhep;
    }

    public void setNgayNghiPhep(Double ngayNghiPhep) {
        this.ngayNghiPhep = ngayNghiPhep;
    }

    public Double getNgayKhongPhep() {
        return ngayKhongPhep;
    }

    public void setNgayKhongPhep(Double ngayKhongPhep) {
        this.ngayKhongPhep = ngayKhongPhep;
    }
}