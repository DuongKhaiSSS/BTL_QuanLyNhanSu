package com.ptit.webnhansu.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_TONGIAO")
public class TonGiao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IDTG")
    private Integer idtg;

    @Column(name = "TENTG")
    private String tentg;

    // Getter & Setter
    public Integer getIdtg() { return idtg; }
    public void setIdtg(Integer idtg) { this.idtg = idtg; }

    public String getTentg() { return tentg; }
    public void setTentg(String tentg) { this.tentg = tentg; }
}