package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.LoaiCong;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoaiCongRepository extends JpaRepository<LoaiCong, Integer> {}