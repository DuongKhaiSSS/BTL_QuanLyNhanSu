package com.ptit.webnhansu.controller;

import com.ptit.webnhansu.entity.LoaiCa;
import com.ptit.webnhansu.repository.LoaiCaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loai-ca")
public class LoaiCaController {

    @Autowired
    private LoaiCaRepository loaiCaRepo;

    // SỬA ĐÚNG DÒNG NÀY: Thêm "/danh-sach" vào để Web tìm thấy đường
    @GetMapping("/danh-sach")
    public List<LoaiCa> getAll() {
        return loaiCaRepo.findAll();
    }

    @PostMapping("/them")
    public LoaiCa save(@RequestBody LoaiCa loaiCa) {
        // Tẩy tủy ID để SQL tự tăng, tránh lỗi 500
        loaiCa.setIdLoaiCa(null);
        return loaiCaRepo.save(loaiCa);
    }
}