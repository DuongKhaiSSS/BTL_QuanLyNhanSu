package com.ptit.webnhansu.controller;

import com.ptit.webnhansu.entity.HopDong;
import com.ptit.webnhansu.repository.HopDongRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/hop-dong")
public class HopDongController {

    @Autowired
    private HopDongRepository hopDongRepo;

    @GetMapping("/danh-sach")
    public List<HopDong> layDanhSach() {
        return hopDongRepo.findAll();
    }

    @PostMapping("/them")
    public ResponseEntity<?> themHopDong(@RequestBody HopDong hdMoi) {

        // Bắt lỗi nếu Swagger gửi maNV = 0 hoặc null
        if (hdMoi.getMaNV() == null || hdMoi.getMaNV() == 0) {
            return ResponseEntity.badRequest().body(
                    "Lỗi: Mã nhân viên không hợp lệ . Hãy kiểm tra lại số maNV trên Swagger!");
        }

        //
        try {
            // 1. NGHIỆP VỤ HỦY HỢP ĐỒNG CŨ
            List<HopDong> danhSachHdCu = hopDongRepo.findByMaNVAndTrangThai(hdMoi.getMaNV(), 1);
            for (HopDong hdCu : danhSachHdCu) {
                hdCu.setTrangThai(0);
                hdCu.setNgayKetThuc(LocalDate.now().minusDays(1));
                hopDongRepo.save(hdCu);
            }

            // 2. LƯU HỢP ĐỒNG MỚI
            hdMoi.setTrangThai(1);
            if (hdMoi.getNgayKy() == null)
                hdMoi.setNgayKy(LocalDate.now());

            HopDong ketQua = hopDongRepo.save(hdMoi);
            return ResponseEntity.ok(ketQua);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Lỗi hệ thống: " + e.getMessage());
        }
    }
}