package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.BangCong;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BangCongRepository extends JpaRepository<BangCong, Integer> {

    List<BangCong> findByNamAndThang(Integer nam, Integer thang);

    Optional<BangCong> findByMaNVAndNamAndThang(Integer maNV, Integer nam, Integer thang);
}