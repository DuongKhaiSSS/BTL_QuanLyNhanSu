package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.HopDong;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface HopDongRepository extends JpaRepository<HopDong, String> {

       List<HopDong> findByMaNV(Integer maNV);

       List<HopDong> findByMaNVAndTrangThai(Integer maNV, Integer trangThai);

       // Dem so hop dong con hieu luc thuc te
       @Query(value = "SELECT COUNT(*) FROM tb_HOPDONG " +
                     "WHERE TRANGTHAI = 1 " +
                     "AND (NGAYKETTHUC >= GETDATE() OR NGAYKETTHUC IS NULL)", nativeQuery = true)
       Long countActiveContracts();

       // Luong TB theo hop dong con hieu luc thuc te
       @Query(value = "SELECT AVG(LUONGCOBAN) FROM tb_HOPDONG " +
                     "WHERE NGAYKETTHUC >= GETDATE() OR NGAYKETTHUC IS NULL", nativeQuery = true)
       Double getAverageSalary();

       // Tong luong theo chuc vu - hop dong con hieu luc thuc te
       @Query(value = "SELECT cv.TENCV, SUM(h.LUONGCOBAN) FROM tb_HOPDONG h " +
                     "JOIN tb_NHANVIEN nv ON h.MANV = nv.MANV " +
                     "JOIN tb_CHUCVU cv ON nv.IDCV = cv.IDCV " +
                     "WHERE h.NGAYKETTHUC >= GETDATE() OR h.NGAYKETTHUC IS NULL " +
                     "GROUP BY cv.TENCV", nativeQuery = true)
       List<Object[]> sumSalaryByChucVu();

       // Tong luong theo phong ban - hop dong con hieu luc thuc te
       @Query(value = "SELECT pb.TENPB, SUM(h.LUONGCOBAN) FROM tb_HOPDONG h " +
                     "JOIN tb_NHANVIEN nv ON h.MANV = nv.MANV " +
                     "JOIN tb_PHONGBAN pb ON nv.IDPB = pb.IDPB " +
                     "WHERE h.NGAYKETTHUC >= GETDATE() OR h.NGAYKETTHUC IS NULL " +
                     "GROUP BY pb.TENPB", nativeQuery = true)
       List<Object[]> sumSalaryByPhongBan();
}