package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.BangLuong;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface BangLuongRepository extends JpaRepository<BangLuong, Integer> {

    // Lấy danh sách lương theo tháng/năm
    List<BangLuong> findByThangAndNam(Integer thang, Integer nam);

    // Kiểm tra đã có bản ghi DA_DUYET chưa
    boolean existsByThangAndNamAndTrangThai(Integer thang, Integer nam, String trangThai);
}