package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.TangCa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface TangCaRepository extends JpaRepository<TangCa, Integer> {
    List<TangCa> findByMaNVAndNamAndThang(Integer maNV, Integer nam, Integer thang);
}