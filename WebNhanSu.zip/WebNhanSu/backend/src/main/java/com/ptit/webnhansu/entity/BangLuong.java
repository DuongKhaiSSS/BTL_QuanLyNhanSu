package com.ptit.webnhansu.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "tb_BANGLUONG")
public class BangLuong {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "NAM")
    private Integer nam;
    @Column(name = "THANG")
    private Integer thang;
    @Column(name = "MANV")
    private Integer maNV;
    @Column(name = "LUONGCOBAN")
    private Double luongCoBan;
    @Column(name = "NGAYCONGTHUCTE")
    private Double ngayCongThucTe;
    @Column(name = "TONGTIEN_TANGCA")
    private Double tongTienTangCa;
    @Column(name = "PHUCAP")
    private Double phuCap;
    @Column(name = "THUCLANH")
    private Double thucLanh;
    @Column(name = "NGAYTINH")
    private LocalDate ngayTinh;

    // ✅ 3 FIELD MỚI
    @Column(name = "trang_thai")
    private String trangThai = "CHO_DUYET";
    @Column(name = "nguoi_duyet")
    private String nguoiDuyet;
    @Column(name = "ngay_duyet")
    private LocalDateTime ngayDuyet;

    // Getter & Setter cũ
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNam() {
        return nam;
    }

    public void setNam(Integer nam) {
        this.nam = nam;
    }

    public Integer getThang() {
        return thang;
    }

    public void setThang(Integer thang) {
        this.thang = thang;
    }

    public Integer getMaNV() {
        return maNV;
    }

    public void setMaNV(Integer maNV) {
        this.maNV = maNV;
    }

    public Double getLuongCoBan() {
        return luongCoBan;
    }

    public void setLuongCoBan(Double luongCoBan) {
        this.luongCoBan = luongCoBan;
    }

    public Double getNgayCongThucTe() {
        return ngayCongThucTe;
    }

    public void setNgayCongThucTe(Double ngayCongThucTe) {
        this.ngayCongThucTe = ngayCongThucTe;
    }

    public Double getTongTienTangCa() {
        return tongTienTangCa;
    }

    public void setTongTienTangCa(Double tongTienTangCa) {
        this.tongTienTangCa = tongTienTangCa;
    }

    public Double getPhuCap() {
        return phuCap;
    }

    public void setPhuCap(Double phuCap) {
        this.phuCap = phuCap;
    }

    public Double getThucLanh() {
        return thucLanh;
    }

    public void setThucLanh(Double thucLanh) {
        this.thucLanh = thucLanh;
    }

    public LocalDate getNgayTinh() {
        return ngayTinh;
    }

    public void setNgayTinh(LocalDate ngayTinh) {
        this.ngayTinh = ngayTinh;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public String getNguoiDuyet() {
        return nguoiDuyet;
    }

    public void setNguoiDuyet(String nguoiDuyet) {
        this.nguoiDuyet = nguoiDuyet;
    }

    public LocalDateTime getNgayDuyet() {
        return ngayDuyet;
    }

    public void setNgayDuyet(LocalDateTime ngayDuyet) {
        this.ngayDuyet = ngayDuyet;
    }
}