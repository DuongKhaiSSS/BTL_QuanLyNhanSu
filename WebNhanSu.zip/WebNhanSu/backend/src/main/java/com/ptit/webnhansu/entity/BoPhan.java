package com.ptit.webnhansu.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_BOPHAN")
public class BoPhan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IDBP")
    private Integer idbp;

    @Column(name = "TENBP")
    private String tenbp;

    // Getter & Setter
    public Integer getIdbp() { return idbp; }
    public void setIdbp(Integer idbp) { this.idbp = idbp; }

    public String getTenbp() { return tenbp; }
    public void setTenbp(String tenbp) { this.tenbp = tenbp; }
}