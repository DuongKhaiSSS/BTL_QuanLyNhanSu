package com.ptit.webnhansu.controller;

import com.ptit.webnhansu.entity.ChucVu;
import com.ptit.webnhansu.repository.ChucVuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException; // Nhớ thêm dòng import này
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/chuc-vu")
public class ChucVuController {

    @Autowired
    private ChucVuRepository chucVuRepository;

    @GetMapping("/danh-sach")
    public List<ChucVu> layDanhSach() {
        return chucVuRepository.findAll();
    }

    @PostMapping("/them")
    public ResponseEntity<?> them(@RequestBody ChucVu chucVu) {
        if (chucVu.getTenCV() == null || chucVu.getTenCV().isBlank()) {
            return ResponseEntity.badRequest().body("Tên chức vụ không được trống!");
        }
        boolean trung = chucVuRepository.findAll()
                .stream().anyMatch(c -> c.getTenCV().equalsIgnoreCase(chucVu.getTenCV()));
        if (trung)
            return ResponseEntity.badRequest().body("Chức vụ đã tồn tại!");
        return ResponseEntity.ok(chucVuRepository.save(chucVu));
    }

    @PutMapping("/sua/{id}")
    public ResponseEntity<?> sua(@PathVariable Integer id, @RequestBody ChucVu chucVu) {
        return chucVuRepository.findById(id).map(cv -> {
            cv.setPhuCap(chucVu.getPhuCap());
            return ResponseEntity.ok(chucVuRepository.save(cv));
        }).orElse(ResponseEntity.badRequest().build());
    }

    @DeleteMapping("/xoa/{id}")
    public ResponseEntity<?> xoa(@PathVariable Integer id) {
        if (!chucVuRepository.existsById(id)) {
            return ResponseEntity.badRequest().body("Không tìm thấy chức vụ!");
        }

        try {
            chucVuRepository.deleteById(id);
            return ResponseEntity.ok("Đã xóa!");
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.badRequest().body("Không thể xóa! Chức vụ này đang được gán cho nhân viên.");
        }
    }
}