package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.ChiTietBangLuong;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ChiTietBangLuongRepository extends JpaRepository<ChiTietBangLuong, Integer> {

    @Modifying
    @Query(value = "DELETE FROM tb_BANGLUONG WHERE nam = :nam AND thang = :thang", nativeQuery = true)
    void deleteByNamAndThang(@Param("nam") Integer nam, @Param("thang") Integer thang);

    List<ChiTietBangLuong> findByNamAndThang(Integer nam, Integer thang);

    List<ChiTietBangLuong> findByMaNVAndNam(Integer maNV, Integer nam);

    // Kiểm tra bảng lương tháng/năm đã duyệt chưa
    boolean existsByThangAndNamAndTrangThai(Integer thang, Integer nam, String trangThai);

    // Lấy tất cả bản ghi theo tháng/năm để cập nhật trạng thái duyệt
    List<ChiTietBangLuong> findByThangAndNam(Integer thang, Integer nam);
}