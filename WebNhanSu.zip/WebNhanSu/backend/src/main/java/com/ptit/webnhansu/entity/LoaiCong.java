package com.ptit.webnhansu.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "tb_LOAICONG")
public class LoaiCong {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IDLC") private Integer idlc;
    @Column(name = "TENLC") private String tenlc;
    @Column(name = "HESO") private Double heSo;

    // Getter & Setter
    public Integer getIdlc() { return idlc; }
    public void setIdlc(Integer idlc) { this.idlc = idlc; }
    public String getTenlc() { return tenlc; }
    public void setTenlc(String tenlc) { this.tenlc = tenlc; }
    public Double getHeSo() { return heSo; }
    public void setHeSo(Double heSo) { this.heSo = heSo; }
}