package com.ptit.webnhansu.service;

import com.ptit.webnhansu.entity.ChucVu;
import com.ptit.webnhansu.entity.NhanVien;
import com.ptit.webnhansu.repository.ChucVuRepository;
import com.ptit.webnhansu.repository.HopDongRepository;
import com.ptit.webnhansu.repository.NhanVienRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class DashboardService {
    @Autowired
    private NhanVienRepository nhanVienRepo;
    @Autowired
    private HopDongRepository hopDongRepo;
    @Autowired
    private ChucVuRepository chucVuRepo;

    public Map<String, Object> getDashboardData() {
        Map<String, Object> finalData = new HashMap<>();
        Map<String, Object> overview = new HashMap<>();
        // 1
        overview.put("totalEmployees", nhanVienRepo.count());
        overview.put("activeEmployees", nhanVienRepo.countByDaThoiViec(0));
        overview.put("activeContracts", hopDongRepo.countActiveContracts());

        Double avgSalary = hopDongRepo.getAverageSalary();
        overview.put("averageSalary", avgSalary != null ? avgSalary : 0.0);

        // 2
        Map<String, Object> charts = new HashMap<>();
        charts.put("roleCounts", convertListToMap(nhanVienRepo.countByChucVu())); //
        charts.put("deptCounts", convertListToMap(nhanVienRepo.countByPhongBan()));
        charts.put("salaryByRole", convertListToMap(hopDongRepo.sumSalaryByChucVu()));
        charts.put("salaryByDept", convertListToMap(hopDongRepo.sumSalaryByPhongBan()));

        // 3
        List<NhanVien> newestList = nhanVienRepo.findTop6ByOrderByMaNVDesc();
        List<Map<String, String>> newestData = newestList.stream().map(nv -> {
            Map<String, String> item = new HashMap<>();
            item.put("name", nv.getHoTen());
            String tenCV = "Chưa xếp";
            if (nv.getIdcv() != null) {
                tenCV = chucVuRepo.findById(nv.getIdcv())
                        .map(ChucVu::getTenCV)
                        .orElse("Chưa xếp");
            }
            item.put("role", tenCV);
            return item;
        }).collect(Collectors.toList());

        // Đóng gói dữ liệu trả về
        finalData.put("overview", overview);
        finalData.put("charts", charts);
        finalData.put("newestEmployees", newestData);
        return finalData;
    }

    // chuyển List sang Map cho dễ dùng ở frontend
    private Map<String, Object> convertListToMap(List<Object[]> list) {
        Map<String, Object> map = new HashMap<>();
        if (list != null) {
            for (Object[] obj : list) {
                if (obj != null && obj[0] != null)
                    map.put(obj[0].toString(), obj[1]);
            }
        }
        return map;
    }
}