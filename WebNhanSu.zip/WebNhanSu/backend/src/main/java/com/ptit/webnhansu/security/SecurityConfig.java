package com.ptit.webnhansu.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Autowired
    private JwtFilter jwtFilter;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth

                        // ── API PUBLIC (khong can token) ──────────────────────
                        .requestMatchers("/api/tai-khoan/dang-nhap").permitAll()
                        .requestMatchers(
                                "/swagger-ui/**",
                                "/error",
                                "/swagger-ui.html",
                                "/v3/api-docs",
                                "/v3/api-docs/**",
                                "/swagger-resources/**",
                                "/webjars/**")
                        .permitAll()

                        // c-quy dinh
                        // ── CHI ADMIN ─────────────────────────────────────────
                        .requestMatchers("/api/tai-khoan/danh-sach").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/tai-khoan/doi-quyen/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/tai-khoan/khoa/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/tai-khoan/reset-mat-khau/**").hasRole("ADMIN")

                        .requestMatchers(HttpMethod.POST, "/api/phong-ban/them").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/phong-ban/xoa/**").hasRole("ADMIN")

                        .requestMatchers(HttpMethod.POST, "/api/chuc-vu/them").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/chuc-vu/sua/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/chuc-vu/xoa/**").hasRole("ADMIN")

                        .requestMatchers(HttpMethod.POST, "/api/loai-ca/them").hasRole("ADMIN")

                        // ── ADMIN & HR ────────────────────────────────────────
                        .requestMatchers(HttpMethod.POST, "/api/nhan-vien/them").hasAnyRole("ADMIN", "HR")
                        .requestMatchers(HttpMethod.PUT, "/api/nhan-vien/sua/**").hasAnyRole("ADMIN", "HR")
                        .requestMatchers(HttpMethod.PUT, "/api/nhan-vien/nghi-viec/**").hasAnyRole("ADMIN", "HR")
                        .requestMatchers(HttpMethod.DELETE, "/api/nhan-vien/xoa/**").hasRole("ADMIN")

                        .requestMatchers(HttpMethod.POST, "/api/hop-dong/them").hasAnyRole("ADMIN", "HR")

                        // ── ADMIN & KE TOAN ───────────────────────────────────
                        .requestMatchers(HttpMethod.POST, "/api/tang-ca/them").hasAnyRole("ADMIN", "ACCOUNTANT")
                        .requestMatchers(HttpMethod.DELETE, "/api/tang-ca/xoa/**").hasAnyRole("ADMIN", "ACCOUNTANT")

                        .requestMatchers(HttpMethod.POST, "/api/bang-cong/luu-danh-sach")
                        .hasAnyRole("ADMIN", "ACCOUNTANT")

                        .requestMatchers(HttpMethod.POST, "/api/bang-luong/tinh-toan").hasAnyRole("ADMIN", "ACCOUNTANT")

                        // ── TAT CA ROLE (can dang nhap) ───────────────────────
                        .anyRequest().authenticated())
                .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOriginPatterns(List.of("*"));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }
}