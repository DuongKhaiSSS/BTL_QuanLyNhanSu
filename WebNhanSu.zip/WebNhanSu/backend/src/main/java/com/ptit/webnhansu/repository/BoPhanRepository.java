package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.BoPhan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BoPhanRepository extends JpaRepository<BoPhan, Integer> {
}