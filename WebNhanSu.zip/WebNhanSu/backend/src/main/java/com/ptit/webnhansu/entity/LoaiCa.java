package com.ptit.webnhansu.entity;

import jakarta.persistence.*;
import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "tb_LOAICA")
public class LoaiCa {
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(hidden = true) // Ẩn ID này đi để Swagger không điền số 0 gây lỗi 500 khi thêm mới
    @Column(name = "IDLOAICA") 
    private Integer idLoaiCa;

    @Column(name = "TENLOAICA") 
    private String tenLoaiCa;

    @Column(name = "HESO") 
    private Double heSo;

    // Getter & Setter giữ nguyên như của ông là ok
    public Integer getIdLoaiCa() { return idLoaiCa; }
    public void setIdLoaiCa(Integer idLoaiCa) { this.idLoaiCa = idLoaiCa; }
    public String getTenLoaiCa() { return tenLoaiCa; }
    public void setTenLoaiCa(String tenLoaiCa) { this.tenLoaiCa = tenLoaiCa; }
    public Double getHeSo() { return heSo; }
    public void setHeSo(Double heSo) { this.heSo = heSo; }
}