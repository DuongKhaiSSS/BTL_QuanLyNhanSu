package com.ptit.webnhansu.controller;

import com.ptit.webnhansu.entity.TaiKhoan;
import com.ptit.webnhansu.repository.TaiKhoanRepository;
import com.ptit.webnhansu.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tai-khoan")
public class TaiKhoanController {

    @Autowired
    private TaiKhoanRepository taiKhoanRepository;

    @Autowired
    private JwtUtil jwtUtil;

    // Lay danh sach tai khoan — ADMIN
    @GetMapping("/danh-sach")
    public List<TaiKhoan> layDanhSach() {
        return taiKhoanRepository.findAll();
    }

    // Dang nhap — Tra ve JWT Token
    @PostMapping("/dang-nhap")
    public ResponseEntity<?> dangNhap(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");

        // 2
        return taiKhoanRepository.findByUsername(username)
                .map(tk -> {
                    if (!tk.getPassword().equals(password))
                        return ResponseEntity.badRequest().body("Sai mật khẩu!");
                    if (tk.getTrangThai() == 0)
                        return ResponseEntity.badRequest().body("Tài khoản đã bị khóa!");

                    // Sinh JWT Token
                    String token = jwtUtil.generateToken(tk.getUsername(), tk.getRole());

                    // Tra ve token + thong tin co ban
                    Map<String, Object> response = new HashMap<>();
                    response.put("token", token);
                    response.put("id", tk.getId());
                    response.put("username", tk.getUsername());
                    response.put("displayName", tk.getDisplayName());
                    response.put("role", tk.getRole());
                    response.put("maNV", tk.getMaNV());

                    return ResponseEntity.ok(response);
                })
                .orElse(ResponseEntity.badRequest().body("Tài khoản không tồn tại!"));
    }

    // Doi quyen — ADMIN
    @PutMapping("/doi-quyen/{id}")
    public ResponseEntity<?> doiQuyen(@PathVariable Integer id,
            @RequestBody Map<String, String> body) {
        return taiKhoanRepository.findById(id).map(tk -> {
            tk.setRole(body.get("role"));
            return ResponseEntity.ok(taiKhoanRepository.save(tk));
        }).orElse(ResponseEntity.badRequest().build());
    }

    // Khoa / Mo khoa tai khoan — ADMIN
    @PutMapping("/khoa/{id}")
    public ResponseEntity<?> khoaTaiKhoan(@PathVariable Integer id) {
        return taiKhoanRepository.findById(id).map(tk -> {
            tk.setTrangThai(tk.getTrangThai() == 1 ? 0 : 1);
            return ResponseEntity.ok(taiKhoanRepository.save(tk));
        }).orElse(ResponseEntity.badRequest().build());
    }

    // Reset mat khau ve 123456 — Chi ADMIN
    @PutMapping("/reset-mat-khau/{id}")
    public ResponseEntity<?> resetMatKhau(@PathVariable Integer id) {
        return taiKhoanRepository.findById(id).map(tk -> {
            tk.setPassword("123456");
            return ResponseEntity.ok(taiKhoanRepository.save(tk));
        }).orElse(ResponseEntity.badRequest().build());
    }
}