package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.LoaiCa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LoaiCaRepository extends JpaRepository<LoaiCa, Integer> {}