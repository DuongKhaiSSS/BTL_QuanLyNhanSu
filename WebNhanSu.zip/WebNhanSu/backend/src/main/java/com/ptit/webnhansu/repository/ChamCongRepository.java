package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.ChamCong;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ChamCongRepository extends JpaRepository<ChamCong, Integer> {
    // Khai báo hàm này để Java tự sinh câu lệnh SQL: SELECT * FROM tb_BANGCONG
    // WHERE NAM = ? AND THANG = ?
    List<ChamCong> findByNamAndThang(Integer nam, Integer thang);
}