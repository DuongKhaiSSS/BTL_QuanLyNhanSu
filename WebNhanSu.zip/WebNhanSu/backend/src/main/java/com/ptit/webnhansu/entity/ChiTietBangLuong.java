package com.ptit.webnhansu.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "tb_BANGLUONG")
public class ChiTietBangLuong {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Integer id;

    @Column(name = "NAM")
    private Integer nam;
    @Column(name = "THANG")
    private Integer thang;
    @Column(name = "MANV")
    private Integer maNV;
    @Column(name = "LUONGCOBAN")
    private Double baseSalary;
    @Column(name = "NGAYCONGTHUCTE")
    private Double workDays;
    @Column(name = "TONGTIEN_TANGCA")
    private Double overtimeMoney;
    @Column(name = "PHUCAP")
    private Double allowance;
    @Column(name = "KHAUTRU")
    private Double deduction;
    @Column(name = "THUCLANH")
    private Double total;
    @Column(name = "NGAYTINH")
    private LocalDateTime ngayTinh;

    // ✅ 3 FIELD MỚI
    @Column(name = "trang_thai")
    private String trangThai = "CHO_DUYET";
    @Column(name = "nguoi_duyet")
    private String nguoiDuyet;
    @Column(name = "ngay_duyet")
    private LocalDateTime ngayDuyet;

    // Getter & Setter cũ
    public Integer getId() {
        return id;
    }

    public Integer getMaNV() {
        return maNV;
    }

    public void setMaNV(Integer maNV) {
        this.maNV = maNV;
    }

    public Integer getNam() {
        return nam;
    }

    public void setNam(Integer nam) {
        this.nam = nam;
    }

    public Integer getThang() {
        return thang;
    }

    public void setThang(Integer thang) {
        this.thang = thang;
    }

    public Double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(Double baseSalary) {
        this.baseSalary = baseSalary;
    }

    public Double getWorkDays() {
        return workDays;
    }

    public void setWorkDays(Double workDays) {
        this.workDays = workDays;
    }

    public Double getOvertimeMoney() {
        return overtimeMoney;
    }

    public void setOvertimeMoney(Double overtimeMoney) {
        this.overtimeMoney = overtimeMoney;
    }

    public Double getAllowance() {
        return allowance;
    }

    public void setAllowance(Double allowance) {
        this.allowance = allowance;
    }

    public Double getDeduction() {
        return deduction;
    }

    public void setDeduction(Double deduction) {
        this.deduction = deduction;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public LocalDateTime getNgayTinh() {
        return ngayTinh;
    }

    public void setNgayTinh(LocalDateTime ngayTinh) {
        this.ngayTinh = ngayTinh;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public String getNguoiDuyet() {
        return nguoiDuyet;
    }

    public void setNguoiDuyet(String nguoiDuyet) {
        this.nguoiDuyet = nguoiDuyet;
    }

    public LocalDateTime getNgayDuyet() {
        return ngayDuyet;
    }

    public void setNgayDuyet(LocalDateTime ngayDuyet) {
        this.ngayDuyet = ngayDuyet;
    }
}