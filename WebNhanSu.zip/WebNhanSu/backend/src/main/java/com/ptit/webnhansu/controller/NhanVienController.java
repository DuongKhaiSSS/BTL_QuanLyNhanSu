package com.ptit.webnhansu.controller;

import com.ptit.webnhansu.entity.NhanVien;
import com.ptit.webnhansu.repository.NhanVienRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException; // Thêm import này
import org.springframework.http.ResponseEntity; // Thêm import này
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/nhan-vien")
public class NhanVienController {

    @Autowired
    private NhanVienRepository nhanVienRepository;

    @GetMapping("/danh-sach")
    public List<NhanVien> layDanhSachNhanVien() {
        return nhanVienRepository.findAll();
    }

    // B
    @PostMapping("/them")
    public NhanVien themNhanVien(@RequestBody NhanVien nhanVien) {
        nhanVien.setMaNV(null);

        if (nhanVien.getIdpb() == null || nhanVien.getIdpb() == 0)
            nhanVien.setIdpb(1);
        if (nhanVien.getIdcv() == null || nhanVien.getIdcv() == 0)
            nhanVien.setIdcv(1);
        if (nhanVien.getIdbp() == null || nhanVien.getIdbp() == 0)
            nhanVien.setIdbp(1);
        if (nhanVien.getIdtd() == null || nhanVien.getIdtd() == 0)
            nhanVien.setIdtd(1);
        if (nhanVien.getIdtg() == null || nhanVien.getIdtg() == 0)
            nhanVien.setIdtg(1);

        nhanVien.setDaThoiViec(0);

        return nhanVienRepository.save(nhanVien);
    }

    @PutMapping("/sua/{id}")
    public NhanVien suaNhanVien(@PathVariable Integer id, @RequestBody NhanVien thongTinMoi) {
        return nhanVienRepository.findById(id)
                .map(nv -> {
                    nv.setHoTen(thongTinMoi.getHoTen());
                    nv.setGioiTinh(thongTinMoi.getGioiTinh());
                    nv.setNgaySinh(thongTinMoi.getNgaySinh());
                    nv.setDienThoai(thongTinMoi.getDienThoai());
                    nv.setCccd(thongTinMoi.getCccd());
                    nv.setDiaChi(thongTinMoi.getDiaChi());
                    nv.setIdpb(thongTinMoi.getIdpb());
                    nv.setIdcv(thongTinMoi.getIdcv());
                    if (thongTinMoi.getDaThoiViec() != null) {
                        nv.setDaThoiViec(thongTinMoi.getDaThoiViec());
                    }
                    return nhanVienRepository.save(nv);
                }).orElseThrow(() -> new RuntimeException("Không tìm thấy nhân viên!"));
    }

    @PutMapping("/nghi-viec/{id}")
    public NhanVien xacNhanNghiViec(@PathVariable Integer id) {
        return nhanVienRepository.findById(id)
                .map(nv -> {
                    nv.setDaThoiViec(1);
                    return nhanVienRepository.save(nv);
                }).orElseThrow(() -> new RuntimeException("Không tìm thấy nhân viên!"));
    }

    @DeleteMapping("/xoa/{id}")
    public ResponseEntity<?> xoaNhanVien(@PathVariable Integer id) {
        if (!nhanVienRepository.existsById(id)) {
            return ResponseEntity.badRequest().body("Không tìm thấy nhân viên!");
        }
        try {
            nhanVienRepository.deleteById(id);
            return ResponseEntity.ok("Đã xóa thành công nhân viên!");
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.badRequest()
                    .body("Không thể xóa! Nhân viên này đang có dữ liệu hợp đồng hoặc bảng công.");
        }
    }
}