package com.ptit.webnhansu.repository;

import com.ptit.webnhansu.entity.ChucVu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ChucVuRepository extends JpaRepository<ChucVu, Integer> {
    @Query(value = "SELECT cv.* FROM tb_CHUCVU cv JOIN tb_NHANVIEN nv ON cv.IDCV = nv.IDCV WHERE nv.MANV = ?1", nativeQuery = true)
    ChucVu findChucVuByMaNV(Integer maNV);
}