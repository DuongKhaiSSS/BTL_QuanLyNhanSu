package com.ptit.webnhansu.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "tb_BANGCONG")
public class ChamCong {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "MABC") // Đúng tên PK trong SQL của ông
    private Integer id;

    @Column(name = "NAM")
    private Integer nam;
    @Column(name = "THANG")
    private Integer thang;
    @Column(name = "MANV")
    private Integer maNV;

    @Column(name = "NGAYCONGTHUCTE")
    private Double ngayCongThucTe;

    @Column(name = "NGAYNGHIPHEP")
    private Double ngayNghiPhep;

    // --- GETTER / SETTER ---
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNam() {
        return nam;
    }

    public void setNam(Integer nam) {
        this.nam = nam;
    }

    public Integer getThang() {
        return thang;
    }

    public void setThang(Integer thang) {
        this.thang = thang;
    }

    public Integer getMaNV() {
        return maNV;
    }

    public void setMaNV(Integer maNV) {
        this.maNV = maNV;
    }

    public Double getNgayCongThucTe() {
        return ngayCongThucTe;
    }

    public void setNgayCongThucTe(Double ngayCongThucTe) {
        this.ngayCongThucTe = ngayCongThucTe;
    }

    public Double getNgayNghiPhep() {
        return ngayNghiPhep;
    }

    public void setNgayNghiPhep(Double ngayNghiPhep) {
        this.ngayNghiPhep = ngayNghiPhep;
    }
}