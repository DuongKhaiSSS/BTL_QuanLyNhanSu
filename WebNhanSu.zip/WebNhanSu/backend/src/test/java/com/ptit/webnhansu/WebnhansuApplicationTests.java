package com.ptit.webnhansu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebnhansuApplicationTests {

	@Test
	void contextLoads() {
	}

}
